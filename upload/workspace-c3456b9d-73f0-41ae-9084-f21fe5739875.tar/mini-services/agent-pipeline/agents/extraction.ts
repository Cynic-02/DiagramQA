// Extraction Agent — uses the Vision LLM to parse a diagram into a structured
// representation: entities, relationships, labels, spatial layout.
//
// Falls back to a deterministic mock when the SDK is unavailable or the call
// fails, so the pipeline keeps moving during demos and offline development.

import ZAI from 'z-ai-web-dev-sdk'
import type { ExtractionResult } from './types.js'
import { extractJson, clip } from './util.js'

export interface ExtractInput {
  dataUrl: string
  mimeType: string
  name: string
}

export interface ExtractOutput {
  result: ExtractionResult
  ok: boolean
  fallback: boolean
  raw?: string
}

let zaiPromise: Promise<any> | null = null
async function getZai() {
  if (!zaiPromise) zaiPromise = ZAI.create()
  return zaiPromise
}

const PROMPT = `You are the Extraction Agent in a multi-agent diagram-to-question pipeline.
Analyze the attached diagram and return ONLY a JSON object with this exact shape:

{
  "diagramType": string,            // e.g. "microservice architecture", "DFD", "circuit", "flowchart"
  "summary": string,                // 1-2 sentence summary of what the diagram represents
  "entities": [
    { "id": "e1", "label": "API Gateway", "type": "service", "position": { "x": 0.3, "y": 0.5 } }
  ],
  "relationships": [
    { "id": "r1", "from": "e1", "to": "e2", "label": "routes to", "kind": "flow" }
  ]
}

Rules:
- "kind" must be one of: "flow" | "data" | "control" | "contains" | "references"
- Position is normalized 0..1 in image space (origin top-left).
- Capture 4-10 entities and 3-10 relationships — be specific, not exhaustive.
- Do NOT include any text outside the JSON object.`

export async function extractDiagram(input: ExtractInput): Promise<ExtractOutput> {
  // Try the real VLM call first.
  try {
    const zai = await getZai()
    const response = await zai.chat.completions.createVision({
      messages: [
        {
          role: 'user',
          content: [
            { type: 'text', text: PROMPT },
            { type: 'image_url', image_url: { url: input.dataUrl } },
          ],
        },
      ],
      thinking: { type: 'disabled' },
    })
    const raw = response?.choices?.[0]?.message?.content ?? ''
    const parsed = extractJson<Partial<ExtractionResult>>(raw)
    if (parsed && Array.isArray(parsed.entities) && Array.isArray(parsed.relationships)) {
      const result: ExtractionResult = {
        diagramType: String(parsed.diagramType ?? 'unknown diagram'),
        summary: String(parsed.summary ?? 'Diagram parsed by the vision agent.'),
        entities: parsed.entities.map((e: any, i: number) => ({
          id: String(e.id ?? `e${i + 1}`),
          label: String(e.label ?? 'unknown'),
          type: String(e.type ?? 'node'),
          position: e.position
            ? { x: Number(e.position.x) ?? 0.5, y: Number(e.position.y) ?? 0.5 }
            : undefined,
        })),
        relationships: parsed.relationships.map((r: any, i: number) => ({
          id: String(r.id ?? `r${i + 1}`),
          from: String(r.from ?? ''),
          to: String(r.to ?? ''),
          label: String(r.label ?? 'relates to'),
          kind: (['flow', 'data', 'control', 'contains', 'references'].includes(r.kind)
            ? r.kind
            : 'flow') as ExtractionResult['relationships'][number]['kind'],
        })),
        rawMarkdown: raw,
      }
      return { result, ok: true, fallback: false, raw }
    }
  } catch (err: any) {
    console.warn('[extraction] VLM call failed, falling back:', err?.message ?? err)
  }

  // Fallback: deterministic mock derived from the file name, so the rest of
  // the pipeline still has structured data to work with.
  const result = mockExtraction(input.name)
  return { result, ok: true, fallback: true, raw: JSON.stringify(result, null, 2) }
}

function mockExtraction(name: string): ExtractionResult {
  const base = name.replace(/\.[^.]+$/, '').replace(/[-_]/g, ' ')
  return {
    diagramType: 'generic architecture (mock fallback)',
    summary: `Mock extraction of "${base}". The vision API was unavailable, so a deterministic placeholder structure was synthesized to keep the pipeline moving.`,
    entities: [
      { id: 'e1', label: 'Client', type: 'actor', position: { x: 0.12, y: 0.5 } },
      { id: 'e2', label: 'Gateway', type: 'service', position: { x: 0.35, y: 0.5 } },
      { id: 'e3', label: 'Auth Service', type: 'service', position: { x: 0.6, y: 0.25 } },
      { id: 'e4', label: 'Core API', type: 'service', position: { x: 0.6, y: 0.75 } },
      { id: 'e5', label: 'Database', type: 'datastore', position: { x: 0.88, y: 0.6 } },
    ],
    relationships: [
      { id: 'r1', from: 'e1', to: 'e2', label: 'sends requests', kind: 'flow' },
      { id: 'r2', from: 'e2', to: 'e3', label: 'verifies token', kind: 'control' },
      { id: 'r3', from: 'e2', to: 'e4', label: 'routes to', kind: 'flow' },
      { id: 'r4', from: 'e4', to: 'e5', label: 'reads / writes', kind: 'data' },
    ],
    rawMarkdown: 'mock extraction (vision API unavailable)',
  }
}

/** Compact the extraction for inclusion in downstream LLM prompts. */
export function compactExtraction(e: ExtractionResult): string {
  const ents = e.entities.map((x) => `- ${x.id}: ${x.label} (${x.type})`).join('\n')
  const rels = e.relationships
    .map((x) => `- ${x.from} --[${x.label}]--> ${x.to}`)
    .join('\n')
  return `diagramType: ${e.diagramType}\nsummary: ${clip(e.summary, 400)}\nentities:\n${ents}\nrelationships:\n${rels}`
}
