// Answering Agent — independently answers each question using ONLY the
// extracted diagram. This is the cross-check that catches the generator
// leaking answers into the question text.

import ZAI from 'z-ai-web-dev-sdk'
import type { AnswerResult, ExtractionResult, GeneratedQuestion } from './types.js'
import { compactExtraction } from './extraction.js'
import { extractJson, shortId } from './util.js'

export interface AnswerInput {
  extraction: ExtractionResult
  question: GeneratedQuestion
}

export interface AnswerOutput {
  answer: AnswerResult
  ok: boolean
  fallback: boolean
}

let zaiPromise: Promise<any> | null = null
async function getZai() {
  if (!zaiPromise) zaiPromise = ZAI.create()
  return zaiPromise
}

export async function answerQuestion(input: AnswerInput): Promise<AnswerOutput> {
  const prompt = `You are the Answering Agent in a multi-agent diagram-to-question pipeline.
A separate Question Agent has produced the question below. You must answer it using
ONLY the diagram extraction provided. You do not see the question generator's
intended answer.

Diagram extraction:
${compactExtraction(input.extraction)}

Question (Bloom's level: ${input.question.bloom}):
${input.question.question}

Return ONLY this JSON shape:
{
  "answer": "your answer, 1-4 sentences, grounded strictly in the diagram",
  "confidence": 0.0-1.0,
  "cited": ["entity ids or relationship ids you used"],
  "assumptions": ["any assumption you had to make beyond the diagram, or empty array"]
}`

  try {
    const zai = await getZai()
    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'assistant', content: 'You are a precise, conservative answering agent. If the diagram does not support an answer, you say so.' },
        { role: 'user', content: prompt },
      ],
      thinking: { type: 'disabled' },
    })
    const raw = completion?.choices?.[0]?.message?.content ?? ''
    const parsed = extractJson<any>(raw)
    if (parsed && typeof parsed.answer === 'string' && parsed.answer.trim().length > 0) {
      const answer: AnswerResult = {
        questionId: input.question.id,
        answer: parsed.answer.trim(),
        confidence: clamp(Number(parsed.confidence) ?? 0.5),
        cited: Array.isArray(parsed.cited) ? parsed.cited.map(String) : [],
        assumptions: Array.isArray(parsed.assumptions) ? parsed.assumptions.map(String) : [],
      }
      return { answer, ok: true, fallback: false }
    }
  } catch (err: any) {
    console.warn('[answering] LLM call failed, falling back:', err?.message ?? err)
  }

  return { answer: mockAnswer(input), ok: true, fallback: true }
}

function clamp(n: number): number {
  if (Number.isNaN(n)) return 0.5
  return Math.min(1, Math.max(0, n))
}

function mockAnswer(input: AnswerInput): AnswerResult {
  const e = input.extraction.entities
  const r = input.extraction.relationships
  // Heuristic answer based on Bloom level
  const templates: Record<string, () => AnswerResult> = {
    remember: () => ({
      questionId: input.question.id,
      answer: `Per the diagram, the component labeled "${e[0]?.label ?? 'A'}" is identified as a ${e[0]?.type ?? 'node'}.`,
      confidence: 0.85,
      cited: [e[0]?.id].filter(Boolean) as string[],
      assumptions: [],
    }),
    understand: () => ({
      questionId: input.question.id,
      answer: `The relationship "${r[0]?.label ?? 'relates to'}" between "${e[0]?.label ?? 'A'}" and "${e[1]?.label ?? 'B'}" indicates a ${r[0]?.kind ?? 'flow'} dependency: the source produces or triggers what the destination consumes.`,
      confidence: 0.7,
      cited: [r[0]?.id, e[0]?.id, e[1]?.id].filter(Boolean) as string[],
      assumptions: ['assuming standard directionality implied by the diagram'],
    }),
    apply: () => ({
      questionId: input.question.id,
      answer: `A request originating at "${e[0]?.label ?? 'A'}" flows through "${e[1]?.label ?? 'B'}"${e[2] ? ` and "${e[2].label}"` : ''} before reaching "${e[e.length - 1]?.label ?? 'Z'}". Each hop corresponds to a labeled relationship in the extraction.`,
      confidence: 0.65,
      cited: r.slice(0, 3).map((x) => x.id),
      assumptions: ['assuming the path follows the dominant flow direction'],
    }),
    analyze: () => ({
      questionId: input.question.id,
      answer: `"${e[1]?.label ?? 'B'}" and "${e[2]?.label ?? 'C'}" serve complementary roles: B mediates control flow while C carries data. They differ in who initiates the relationship and what is exchanged.`,
      confidence: 0.6,
      cited: [e[1]?.id, e[2]?.id].filter(Boolean) as string[],
      assumptions: ['assuming role labels are conventionally interpreted'],
    }),
    evaluate: () => ({
      questionId: input.question.id,
      answer: `The most critical relationship is "${r[0]?.label ?? 'the primary flow'}" between "${e[0]?.label ?? 'A'}" and "${e[1]?.label ?? 'B'}" because all downstream paths depend on it; removing it would break the end-to-end flow.`,
      confidence: 0.55,
      cited: [r[0]?.id].filter(Boolean) as string[],
      assumptions: ['assuming the diagram implies dependency through connectivity'],
    }),
    create: () => ({
      questionId: input.question.id,
      answer: `A reasonable extension is a "${'Caching Layer'}" placed between "${e[0]?.label ?? 'A'}" and "${e[1]?.label ?? 'B'}" to absorb repeated reads; it would connect to both via a "data" relationship.`,
      confidence: 0.5,
      cited: [e[0]?.id, e[1]?.id].filter(Boolean) as string[],
      assumptions: ['assuming read-heavy workload', 'assuming cache coherence is out of scope'],
    }),
  }
  return (templates[input.question.bloom] ?? templates.understand)()
}
