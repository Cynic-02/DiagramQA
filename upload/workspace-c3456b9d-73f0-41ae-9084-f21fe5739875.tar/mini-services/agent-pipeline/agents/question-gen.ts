// Question Generation Agent — produces Bloom's-conditioned questions grounded
// in the extracted diagram structure. The generator is given ONLY the
// extraction (no answers); the Answering Agent will derive answers
// independently from the same diagram, to catch leaks.

import ZAI from 'z-ai-web-dev-sdk'
import type { BloomLevel, ExtractionResult, GeneratedQuestion } from './types.js'
import { BLOOM_LEVELS } from './bloom.js'
import { extractJson, shortId } from './util.js'

export interface GenInput {
  extraction: ExtractionResult
  bloom: BloomLevel
  count: number
}

export interface GenOutput {
  questions: GeneratedQuestion[]
  ok: boolean
  fallback: boolean
  raw?: string
}

let zaiPromise: Promise<any> | null = null
async function getZai() {
  if (!zaiPromise) zaiPromise = ZAI.create()
  return zaiPromise
}

export async function generateQuestions(input: GenInput): Promise<GenOutput> {
  const meta = BLOOM_LEVELS.find((b) => b.id === input.bloom) ?? BLOOM_LEVELS[2]
  const prompt = buildPrompt(input, meta.verbs, meta.label, meta.description)

  try {
    const zai = await getZai()
    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'assistant',
          content:
            'You are the Question Generation Agent in a multi-agent diagram-to-question pipeline. ' +
            'You receive a structured extraction of a diagram and must generate questions that are ' +
            'answerable from the diagram alone. You NEVER include the answer in the question. ' +
            'You output ONLY a JSON object.',
        },
        { role: 'user', content: prompt },
      ],
      thinking: { type: 'disabled' },
    })
    const raw = completion?.choices?.[0]?.message?.content ?? ''
    const parsed = extractJson<{ questions: any[] }>(raw)
    if (parsed && Array.isArray(parsed.questions) && parsed.questions.length > 0) {
      const questions: GeneratedQuestion[] = parsed.questions.slice(0, input.count).map((q: any) => ({
        id: String(q.id ?? shortId('q_')),
        question: String(q.question ?? '').trim(),
        bloom: input.bloom,
        skill: String(q.skill ?? meta.verbs[0] ?? 'reasoning'),
        rationale: String(q.rationale ?? 'grounded in extracted structure'),
      })).filter((q) => q.question.length > 0)
      if (questions.length > 0) {
        return { questions, ok: true, fallback: false, raw }
      }
    }
  } catch (err: any) {
    console.warn('[question-gen] LLM call failed, falling back:', err?.message ?? err)
  }
  return { questions: mockQuestions(input, meta.label, meta.verbs[0]), ok: true, fallback: true }
}

function buildPrompt(
  input: GenInput,
  verbs: string[],
  label: string,
  description: string,
): string {
  const ents = input.extraction.entities.map((e) => `- ${e.id}: ${e.label} (${e.type})`).join('\n')
  const rels = input.extraction.relationships
    .map((r) => `- ${r.from} --[${r.label}]--> ${r.to}`)
    .join('\n')
  return `Diagram extraction:
type: ${input.extraction.diagramType}
summary: ${input.extraction.summary}

entities:
${ents}

relationships:
${rels}

Generate exactly ${input.count} questions at the "${label}" level of Bloom's taxonomy.
Bloom's "${label}" definition: ${description}
Target verbs: ${verbs.join(', ')}.

Return ONLY this JSON shape:
{
  "questions": [
    {
      "id": "q_1",
      "question": "the question text, answerable from the diagram alone",
      "skill": "the primary verb targeted",
      "rationale": "one sentence on why this question fits this Bloom's level for this diagram"
    }
  ]
}

Hard constraints:
- The question must be answerable using ONLY the diagram (no outside knowledge).
- Do NOT include the answer in the question.
- Vary question structure across the ${input.count} items.
- Keep each question under 40 words.`
}

function mockQuestions(input: GenInput, label: string, verb: string): GeneratedQuestion[] {
  const out: GeneratedQuestion[] = []
  const e = input.extraction.entities
  const r = input.extraction.relationships
  const templates: Record<BloomLevel, (i: number) => string> = {
    remember: (i) => `Name the ${e[i % e.length]?.type ?? 'component'} labeled "${e[i % e.length]?.label ?? 'X'}".`,
    understand: (_i) => `In your own words, describe what the relationship "${r[0]?.label ?? 'connects'}" between "${e[0]?.label ?? 'A'}" and "${e[1]?.label ?? 'B'}" represents.`,
    apply: (_i) => `Trace the path a request takes from "${e[0]?.label ?? 'A'}" to "${e[e.length - 1]?.label ?? 'Z'}".`,
    analyze: (_i) => `Compare the roles of "${e[1]?.label ?? 'B'}" and "${e[2]?.label ?? 'C'}" in this diagram.`,
    evaluate: (_i) => `Which relationship in the diagram is most critical to the overall flow, and why?`,
    create: (_i) => `Propose a new component that would extend this diagram, and describe where it would connect.`,
  }
  const t = templates[input.bloom]
  for (let i = 0; i < input.count; i++) {
    out.push({
      id: shortId('q_'),
      question: t(i),
      bloom: input.bloom,
      skill: verb,
      rationale: `Mock question at the ${label} level, derived from the extracted structure (LLM unavailable).`,
    })
  }
  return out
}
