// Shared utilities for the agent pipeline.

/** Robust JSON extraction — LLMs love to wrap JSON in prose or fences. */
export function extractJson<T = any>(raw: string): T | null {
  if (!raw) return null
  // Strip ```json fences
  let s = raw.trim()
  const fence = s.match(/```(?:json)?\s*([\s\S]*?)```/i)
  if (fence) s = fence[1].trim()
  // Try direct parse
  try {
    return JSON.parse(s) as T
  } catch {
    /* fall through */
  }
  // Find the first { or [ and match to the last } or ]
  const firstObj = s.indexOf('{')
  const firstArr = s.indexOf('[')
  let start = -1
  let open = ''
  let close = ''
  if (firstObj === -1 && firstArr === -1) return null
  if (firstObj === -1) {
    start = firstArr
    open = '['
    close = ']'
  } else if (firstArr === -1) {
    start = firstObj
    open = '{'
    close = '}'
  } else {
    if (firstObj < firstArr) {
      start = firstObj
      open = '{'
      close = '}'
    } else {
      start = firstArr
      open = '['
      close = ']'
    }
  }
  let depth = 0
  let inStr = false
  let esc = false
  for (let i = start; i < s.length; i++) {
    const c = s[i]
    if (inStr) {
      if (esc) esc = false
      else if (c === '\\') esc = true
      else if (c === '"') inStr = false
      continue
    }
    if (c === '"') inStr = true
    else if (c === open) depth++
    else if (c === close) {
      depth--
      if (depth === 0) {
        const slice = s.slice(start, i + 1)
        try {
          return JSON.parse(slice) as T
        } catch {
          return null
        }
      }
    }
  }
  return null
}

/** Promise-based sleep. */
export const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms))

/** Stable short id. */
export function shortId(prefix = ''): string {
  return `${prefix}${Math.random().toString(36).slice(2, 9)}`
}

/** Trim a string to a max length, ellipsizing. */
export function clip(s: string, n = 200): string {
  if (s.length <= n) return s
  return s.slice(0, n - 1) + '…'
}
