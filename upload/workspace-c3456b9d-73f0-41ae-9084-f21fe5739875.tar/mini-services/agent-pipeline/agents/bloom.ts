// Bloom metadata — mirror of src/lib/bloom.ts for the mini-service.

import type { BloomLevel } from './types.js'

export interface BloomMeta {
  id: BloomLevel
  label: string
  verbs: string[]
  description: string
  rank: number
}

export const BLOOM_LEVELS: BloomMeta[] = [
  {
    id: 'remember',
    label: 'Remember',
    verbs: ['define', 'list', 'name', 'identify', 'label', 'recall'],
    description: 'Direct recall of entities, labels, and relationships explicitly present in the diagram.',
    rank: 0,
  },
  {
    id: 'understand',
    label: 'Understand',
    verbs: ['describe', 'summarize', 'explain', 'interpret', 'classify'],
    description: "Restate what the diagram represents in the student's own words.",
    rank: 1,
  },
  {
    id: 'apply',
    label: 'Apply',
    verbs: ['trace', 'demonstrate', 'implement', 'execute', 'compute'],
    description: 'Follow a path or process through the diagram to a concrete outcome.',
    rank: 2,
  },
  {
    id: 'analyze',
    label: 'Analyze',
    verbs: ['compare', 'contrast', 'decompose', 'differentiate', 'relate'],
    description: 'Break the diagram into parts and reason about why entities relate the way they do.',
    rank: 3,
  },
  {
    id: 'evaluate',
    label: 'Evaluate',
    verbs: ['justify', 'critique', 'assess', 'defend', 'prioritize'],
    description: 'Make a judgment against criteria.',
    rank: 4,
  },
  {
    id: 'create',
    label: 'Create',
    verbs: ['design', 'propose', 'extend', 'modify', 'generate'],
    description: 'Compose a new variant — add a node, reroute a flow, propose an alternative.',
    rank: 5,
  },
]
