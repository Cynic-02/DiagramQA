// Verification Agent — checks each Q&A pair for:
//   1. correctness (the answer follows from the diagram)
//   2. ambiguity (the question has a single defensible answer)
//   3. difficultyMatch (the question actually targets the claimed Bloom's level)
//   4. leaksAnswer (the generator embedded the answer in the question)
//
// Verdict:
//   - "pass"       → keep the pair
//   - "regenerate" → throw back to the Question Agent (loop)
//   - "flag"       → keep but show a warning in the UI

import ZAI from 'z-ai-web-dev-sdk'
import type {
  AnswerResult,
  ExtractionResult,
  GeneratedQuestion,
  VerificationResult,
} from './types.js'
import { compactExtraction } from './extraction.js'
import { extractJson } from './util.js'

export interface VerifyInput {
  extraction: ExtractionResult
  question: GeneratedQuestion
  answer: AnswerResult
}

export interface VerifyOutput {
  verification: VerificationResult
  ok: boolean
  fallback: boolean
}

let zaiPromise: Promise<any> | null = null
async function getZai() {
  if (!zaiPromise) zaiPromise = ZAI.create()
  return zaiPromise
}

export async function verifyPair(input: VerifyInput): Promise<VerifyOutput> {
  const prompt = `You are the Verification Agent in a multi-agent diagram-to-question pipeline.
You receive a question, an independently-derived answer, and the diagram extraction.
You must judge the Q&A pair on four axes.

Diagram extraction:
${compactExtraction(input.extraction)}

Question (Bloom's level: ${input.question.bloom}, claimed skill: ${input.question.skill}):
${input.question.question}

Answer:
${input.answer.answer}
(cited: ${input.answer.cited.join(', ') || 'none'}; confidence: ${input.answer.confidence.toFixed(2)}; assumptions: ${input.answer.assumptions.join('; ') || 'none'})

Return ONLY this JSON shape:
{
  "correct": true | false,           // does the answer follow from the diagram?
  "ambiguity": 0.0-1.0,              // how ambiguous is the question?
  "difficultyMatch": 0.0-1.0,        // does the question actually target the claimed Bloom's level?
  "leaksAnswer": true | false,       // does the question text contain the answer?
  "verdict": "pass" | "regenerate" | "flag",
  "notes": "one sentence rationale"
}`

  try {
    const zai = await getZai()
    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'assistant', content: 'You are a strict but fair verification agent. You reject lazy questions, leaked answers, and Bloom\'s-level mismatches.' },
        { role: 'user', content: prompt },
      ],
      thinking: { type: 'disabled' },
    })
    const raw = completion?.choices?.[0]?.message?.content ?? ''
    const parsed = extractJson<any>(raw)
    if (parsed && typeof parsed.notes === 'string') {
      const verdict = (['pass', 'regenerate', 'flag'].includes(parsed.verdict)
        ? parsed.verdict
        : 'flag') as VerificationResult['verdict']
      const verification: VerificationResult = {
        questionId: input.question.id,
        verdict,
        correct: Boolean(parsed.correct),
        ambiguity: clamp(Number(parsed.ambiguity) ?? 0.5),
        difficultyMatch: clamp(Number(parsed.difficultyMatch) ?? 0.5),
        notes: parsed.notes,
        leaksAnswer: Boolean(parsed.leaksAnswer),
      }
      return { verification, ok: true, fallback: false }
    }
  } catch (err: any) {
    console.warn('[verification] LLM call failed, falling back:', err?.message ?? err)
  }

  return { verification: mockVerification(input), ok: true, fallback: true }
}

function clamp(n: number): number {
  if (Number.isNaN(n)) return 0.5
  return Math.min(1, Math.max(0, n))
}

function mockVerification(input: VerifyInput): VerificationResult {
  // Deterministic heuristic — pass with mild notes; flag if the answer is too short
  // or confidence is very low; never leaks by construction.
  const q = input.question.question.toLowerCase()
  const a = input.answer.answer.toLowerCase()
  let leaksAnswer = false
  // Crude leak check: any 4-word phrase from the answer appearing in the question.
  const aWords = a.split(/\s+/).filter((w) => w.length > 4)
  for (let i = 0; i + 3 < aWords.length; i++) {
    const phrase = aWords.slice(i, i + 4).join(' ')
    if (phrase.length > 16 && q.includes(phrase)) {
      leaksAnswer = true
      break
    }
  }
  const correct = input.answer.confidence >= 0.4
  const ambiguity = input.answer.confidence < 0.5 ? 0.6 : 0.2
  const difficultyMatch = 0.75
  let verdict: VerificationResult['verdict'] = 'pass'
  let notes = 'Pair passes verification (mock fallback).'
  if (leaksAnswer) {
    verdict = 'regenerate'
    notes = 'Generator appears to leak the answer into the question — requesting regeneration.'
  } else if (!correct || ambiguity > 0.7) {
    verdict = 'flag'
    notes = 'Low answer confidence or high ambiguity — kept but flagged for review.'
  }
  return {
    questionId: input.question.id,
    verdict,
    correct,
    ambiguity,
    difficultyMatch,
    notes,
    leaksAnswer,
  }
}
