// Shared types for the agent-pipeline mini-service.
// Mirrors the frontend types in src/lib/types.ts so the wire protocol stays
// in sync without a shared package.

export type StageId =
  | 'upload'
  | 'extraction'
  | 'question-generation'
  | 'answering'
  | 'verification'
  | 'results'

export type StageStatus = 'idle' | 'running' | 'done' | 'flagged' | 'rejected'

export type BloomLevel =
  | 'remember'
  | 'understand'
  | 'apply'
  | 'analyze'
  | 'evaluate'
  | 'create'

export interface ExtractedEntity {
  id: string
  label: string
  type: string
  position?: { x: number; y: number }
}

export interface ExtractedRelationship {
  id: string
  from: string
  to: string
  label: string
  kind?: 'flow' | 'data' | 'control' | 'contains' | 'references'
}

export interface ExtractionResult {
  diagramType: string
  summary: string
  entities: ExtractedEntity[]
  relationships: ExtractedRelationship[]
  rawMarkdown: string
}

export interface GeneratedQuestion {
  id: string
  question: string
  bloom: BloomLevel
  skill: string
  rationale: string
}

export interface AnswerResult {
  questionId: string
  answer: string
  confidence: number
  cited: string[]
  assumptions: string[]
}

export type VerificationVerdict = 'pass' | 'regenerate' | 'flag'

export interface VerificationResult {
  questionId: string
  verdict: VerificationVerdict
  correct: boolean
  ambiguity: number
  difficultyMatch: number
  notes: string
  leaksAnswer: boolean
}

export interface QAPair {
  id: string
  question: GeneratedQuestion
  answer: AnswerResult | null
  verification: VerificationResult | null
  attempts: number
}

export interface PipelineRunMeta {
  runId: string
  startedAt: number
  finishedAt?: number
  bloom: BloomLevel
  questionCount: number
}

export type PipelineEvent =
  | { type: 'stage:start'; stage: StageId }
  | { type: 'stage:progress'; stage: StageId; message: string; level?: 'info' | 'warn' | 'error' | 'thought' }
  | { type: 'stage:done'; stage: StageId; note?: string }
  | { type: 'stage:flagged'; stage: StageId; note: string }
  | { type: 'stage:rejected'; stage: StageId; note: string }
  | { type: 'extraction'; data: ExtractionResult }
  | { type: 'question'; data: GeneratedQuestion }
  | { type: 'answer'; data: AnswerResult }
  | { type: 'verification'; data: VerificationResult }
  | { type: 'pair:regenerate'; questionId: string; reason: string }
  | { type: 'run:complete'; meta: PipelineRunMeta }
  | { type: 'run:error'; message: string; stage?: StageId }

export type PipelineCommand =
  | {
      type: 'run:start'
      diagram: { name: string; mimeType: string; dataUrl: string }
      bloom: BloomLevel
      questionCount: number
    }
  | { type: 'run:cancel' }
