// AR2-DDCQG agent pipeline orchestrator.
//
// Multi-agent flow:
//   1. Extraction (VLM)        — parse the diagram into entities/relationships
//   2. Question Generation      — Bloom's-conditioned questions from the structure
//   3. Answering                — independent answer per question
//   4. Verification             — judge each pair; can loop back to (2) up to MAX_ATTEMPTS
//
// Each agent emits live progress events over socket.io so the frontend can
// stream agent activity instead of jumping from spinner to result.

import { createServer } from 'http'
import { Server, type Socket } from 'socket.io'
import { extractDiagram } from './agents/extraction.js'
import { generateQuestions } from './agents/question-gen.js'
import { answerQuestion } from './agents/answering.js'
import { verifyPair } from './agents/verification.js'
import { sleep, shortId } from './agents/util.js'
import type {
  BloomLevel,
  PipelineCommand,
  PipelineEvent,
  PipelineRunMeta,
  StageId,
} from './agents/types.js'

const PORT = 3003
const MAX_REGEN_ATTEMPTS = 2

const httpServer = createServer()
const io = new Server(httpServer, {
  path: '/',
  cors: { origin: '*', methods: ['GET', 'POST'] },
  pingTimeout: 60000,
  pingInterval: 25000,
  maxHttpBufferSize: 50 * 1024 * 1024, // 50MB — diagrams can be large
})

// Track active run per socket so we can cancel cleanly.
interface RunHandle {
  cancelled: boolean
  runId: string
}
const runs = new Map<Socket, RunHandle>()

io.on('connection', (socket) => {
  console.log(`[agent-pipeline] client connected: ${socket.id}`)

  socket.on('command', async (cmd: PipelineCommand) => {
    if (cmd.type === 'run:cancel') {
      const h = runs.get(socket)
      if (h) h.cancelled = true
      return
    }
    if (cmd.type === 'run:start') {
      // One run at a time per socket.
      const prev = runs.get(socket)
      if (prev) prev.cancelled = true
      const handle: RunHandle = { cancelled: false, runId: shortId('run_') }
      runs.set(socket, handle)
      try {
        await runPipeline(socket, handle, cmd)
      } catch (err: any) {
        console.error('[agent-pipeline] run crashed:', err)
        emit(socket, {
          type: 'run:error',
          message: err?.message ?? 'Pipeline crashed unexpectedly.',
        })
      } finally {
        runs.delete(socket)
      }
    }
  })

  socket.on('disconnect', () => {
    const h = runs.get(socket)
    if (h) h.cancelled = true
    runs.delete(socket)
    console.log(`[agent-pipeline] client disconnected: ${socket.id}`)
  })
})

function emit(socket: Socket, e: PipelineEvent) {
  socket.emit('pipeline:event', e)
}

async function runPipeline(
  socket: Socket,
  handle: RunHandle,
  cmd: Extract<typeof cmd>,
) {
  const startedAt = Date.now()
  const bloom: BloomLevel = cmd.bloom
  const questionCount = Math.max(1, Math.min(8, cmd.questionCount))

  // ── Stage 1: Extraction ───────────────────────────────────────────────
  emitStageStart(socket, 'extraction')
  emitProgress(socket, 'extraction', 'vision agent: opening diagram…', 'info')
  await sleep(400)
  if (handle.cancelled) return cancel(socket)

  emitProgress(socket, 'extraction', 'vision agent: parsing entities and relationships…', 'thought')
  const ex = await extractDiagram({
    dataUrl: cmd.diagram.dataUrl,
    mimeType: cmd.diagram.mimeType,
    name: cmd.diagram.name,
  })
  if (handle.cancelled) return cancel(socket)

  if (!ex.ok || ex.result.entities.length === 0) {
    emit(socket, { type: 'stage:rejected', stage: 'extraction', note: 'No entities extracted from the diagram.' })
    emit(socket, { type: 'run:error', message: 'Extraction produced no entities.', stage: 'extraction' })
    return
  }

  emit(socket, { type: 'extraction', data: ex.result })
  emitStageDone(
    socket,
    'extraction',
    ex.fallback
      ? 'vision API unavailable — used deterministic fallback'
      : `extracted ${ex.result.entities.length} entities, ${ex.result.relationships.length} relationships`,
  )

  // ── Stage 2: Question Generation ──────────────────────────────────────
  emitStageStart(socket, 'question-generation')
  emitProgress(socket, 'question-generation', `conditioning on Bloom's "${bloom}"…`, 'info')
  await sleep(300)
  if (handle.cancelled) return cancel(socket)

  const gen = await generateQuestions({
    extraction: ex.result,
    bloom,
    count: questionCount,
  })
  if (handle.cancelled) return cancel(socket)

  if (gen.questions.length === 0) {
    emit(socket, { type: 'stage:rejected', stage: 'question-generation', note: 'Generator produced no questions.' })
    emit(socket, { type: 'run:error', message: 'Question generation produced no candidates.', stage: 'question-generation' })
    return
  }

  for (const q of gen.questions) {
    emit(socket, { type: 'question', data: q })
    await sleep(180) // small stagger so the UI can animate them in
  }
  emitStageDone(
    socket,
    'question-generation',
    gen.fallback
      ? 'LLM unavailable — used deterministic fallback questions'
      : `generated ${gen.questions.length} questions at "${bloom}" level`,
  )

  // ── Stage 3: Answering ────────────────────────────────────────────────
  emitStageStart(socket, 'answering')
  emitProgress(socket, 'answering', 'answering each question from the diagram only — no peeking at intended answers', 'thought')
  await sleep(250)

  // We materialize the working set of pairs here. Regeneration may replace
  // some questions; we track them by id.
  const working = new Map<string, { question: typeof gen.questions[number]; attempts: number }>()
  for (const q of gen.questions) working.set(q.id, { question: q, attempts: 0 })

  // First pass: answer every question.
  for (const [id, entry] of working) {
    if (handle.cancelled) return cancel(socket)
    emitProgress(socket, 'answering', `answering ${id}…`, 'info')
    const a = await answerQuestion({ extraction: ex.result, question: entry.question })
    emit(socket, { type: 'answer', data: a.answer })
    await sleep(120)
  }
  emitStageDone(socket, 'answering', `answered ${working.size} questions independently`)

  // ── Stage 4: Verification loop ────────────────────────────────────────
  emitStageStart(socket, 'verification')
  emitProgress(socket, 'verification', 'judging correctness, ambiguity, Bloom\'s match, and answer-leak…', 'thought')
  await sleep(250)

  // We need the answers alongside each question; the client stored them.
  // For verification we re-derive the latest answer from the in-memory map
  // by re-answering — but that would be wasteful. Instead, we keep a local
  // map of questionId -> AnswerResult by re-running the answerer on demand.
  // (In production this would be cached; here we keep it simple.)
  const answers = new Map<string, Awaited<ReturnType<typeof answerQuestion>>['answer']>()

  for (const [id, entry] of working) {
    if (handle.cancelled) return cancel(socket)
    let ans = answers.get(id)
    if (!ans) {
      const a = await answerQuestion({ extraction: ex.result, question: entry.question })
      ans = a.answer
      answers.set(id, ans)
    }
    emitProgress(socket, 'verification', `verifying ${id}…`, 'info')
    const v = await verifyPair({ extraction: ex.result, question: entry.question, answer: ans })
    emit(socket, { type: 'verification', data: v.verification })

    // Loop back to regeneration if needed.
    if (v.verification.verdict === 'regenerate' && entry.attempts < MAX_REGEN_ATTEMPTS) {
      entry.attempts += 1
      emit(socket, {
        type: 'pair:regenerate',
        questionId: id,
        reason: v.verification.notes,
      })
      emitProgress(
        socket,
        'verification',
        `regenerating ${id} (attempt ${entry.attempts + 1}/${MAX_REGEN_ATTEMPTS + 1})…`,
        'warn',
      )
      // Re-generate this single question.
      const regen = await generateQuestions({
        extraction: ex.result,
        bloom,
        count: 1,
      })
      if (regen.questions.length > 0) {
        const newQ = { ...regen.questions[0], id } // keep id stable across regen
        entry.question = newQ
        emit(socket, { type: 'question', data: newQ })
        // Re-answer.
        const a2 = await answerQuestion({ extraction: ex.result, question: newQ })
        answers.set(id, a2.answer)
        emit(socket, { type: 'answer', data: a2.answer })
        // Re-verify.
        const v2 = await verifyPair({
          extraction: ex.result,
          question: newQ,
          answer: a2.answer,
        })
        emit(socket, { type: 'verification', data: v2.verification })
      }
    }
    await sleep(120)
  }

  emitStageDone(socket, 'verification', 'all pairs verified')

  // ── Done ──────────────────────────────────────────────────────────────
  const meta: PipelineRunMeta = {
    runId: handle.runId,
    startedAt,
    finishedAt: Date.now(),
    bloom,
    questionCount,
  }
  emit(socket, { type: 'run:complete', meta })
}

// Helper type — extract the inner type of a union member.
type Extract<T> = T extends { type: 'run:start' } ? T : never

function emitStageStart(socket: Socket, stage: StageId) {
  emit(socket, { type: 'stage:start', stage })
}
function emitStageDone(socket: Socket, stage: StageId, note?: string) {
  emit(socket, { type: 'stage:done', stage, note })
}
function emitProgress(
  socket: Socket,
  stage: StageId,
  message: string,
  level: 'info' | 'warn' | 'error' | 'thought' = 'info',
) {
  emit(socket, { type: 'stage:progress', stage, message, level })
}
function cancel(socket: Socket) {
  emit(socket, { type: 'run:error', message: 'Run cancelled.' })
}

httpServer.listen(PORT, () => {
  console.log(`[agent-pipeline] socket.io server listening on :${PORT}`)
})

process.on('SIGTERM', () => {
  httpServer.close(() => process.exit(0))
})
process.on('SIGINT', () => {
  httpServer.close(() => process.exit(0))
})
