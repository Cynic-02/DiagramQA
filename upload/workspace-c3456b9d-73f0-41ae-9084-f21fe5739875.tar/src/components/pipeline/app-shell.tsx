'use client'

import { motion } from 'framer-motion'
import { ArrowLeft, PanelRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import PipelineSidebar from './pipeline-sidebar'
import RightPanel from './right-panel'
import UploadView from './stage-views/upload-view'
import ExtractionView from './stage-views/extraction-view'
import SplitView from './stage-views/split-view'
import VerificationView from './stage-views/verification-view'
import ResultsView from './stage-views/results-view'
import { usePipelineStore } from '@/lib/store'
import { getStageMeta } from '@/lib/bloom'
import { usePipelineSocket } from '@/hooks/use-pipeline-socket'

export default function AppShell({ onExit }: { onExit: () => void }) {
  // Subscribe to socket events once at the app shell level.
  usePipelineSocket()

  const activeStage = usePipelineStore((s) => s.activeStage)
  const rightPanelOpen = usePipelineStore((s) => s.rightPanelOpen)
  const toggleRightPanel = usePipelineStore((s) => s.toggleRightPanel)
  const meta = getStageMeta(activeStage)

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="flex h-screen w-full bg-background"
    >
      <PipelineSidebar onEnter={onExit} />

      <main className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <header className="shrink-0 h-14 border-b border-border flex items-center gap-3 px-4 backdrop-blur-sm bg-background/60">
          <Button
            variant="ghost"
            size="sm"
            onClick={onExit}
            className="text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="mr-1.5 size-3.5" />
            Hero
          </Button>
          <div className="h-4 w-px bg-border" />
          <div className="flex items-center gap-2 min-w-0">
            <span className="text-xs text-muted-foreground">{meta.agent}</span>
            <span className="text-muted-foreground/30">/</span>
            <span className="text-sm font-medium truncate">{meta.label}</span>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <div className="text-xs text-muted-foreground hidden lg:block mr-2 max-w-md truncate">
              {meta.description}
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleRightPanel}
              className={
                rightPanelOpen
                  ? 'text-agent bg-agent/10'
                  : 'text-muted-foreground hover:text-foreground'
              }
              aria-label="Toggle context panel"
            >
              <PanelRight className="size-3.5" />
              <span className="ml-1.5 hidden sm:inline">Context</span>
            </Button>
          </div>
        </header>

        {/* Stage content — fills the remaining space.
            Each stage view manages its own scroll. Cross-fade without mode="wait"
            to avoid getting stuck on exit animations of layout-heavy views. */}
        <div className="flex-1 overflow-hidden relative">
          <motion.div
            key={activeStage}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.2 }}
            className="h-full"
          >
            {activeStage === 'upload' && <UploadView />}
            {activeStage === 'extraction' && <ExtractionView />}
            {(activeStage === 'question-generation' || activeStage === 'answering') && (
              <SplitView activeHalf={activeStage} />
            )}
            {activeStage === 'verification' && <VerificationView />}
            {activeStage === 'results' && <ResultsView />}
          </motion.div>
        </div>
      </main>

      <RightPanel />
    </motion.div>
  )
}
