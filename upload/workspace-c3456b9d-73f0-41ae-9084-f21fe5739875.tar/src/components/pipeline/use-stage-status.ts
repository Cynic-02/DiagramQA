'use client'

import { usePipelineStore } from '@/lib/store'
import type { StageId, StageStatus } from '@/lib/types'

/** Convenience hook for reading a single stage's current status. */
export function usePipelineStageStatus(stage: StageId): StageStatus {
  return usePipelineStore((s) => s.stages[stage].status)
}
