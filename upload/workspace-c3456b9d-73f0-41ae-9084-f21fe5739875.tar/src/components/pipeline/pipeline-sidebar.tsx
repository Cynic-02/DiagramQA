'use client'

import { motion, AnimatePresence } from 'framer-motion'
import {
  Upload,
  ScanEye,
  MessageSquarePlus,
  Sparkles,
  ShieldCheck,
  Trophy,
  ChevronLeft,
  ChevronRight,
  Circle,
  Loader2,
  Check,
  AlertTriangle,
  XCircle,
  type LucideIcon,
} from 'lucide-react'
import { useState } from 'react'
import { PIPELINE_STAGES, STATUS_STYLES, type StageMeta } from '@/lib/bloom'
import { usePipelineStore } from '@/lib/store'
import type { StageId, StageStatus } from '@/lib/types'
import { cn } from '@/lib/utils'

const ICONS: Record<string, LucideIcon> = {
  Upload,
  ScanEye,
  MessageSquarePlus,
  Sparkles,
  ShieldCheck,
  Trophy,
}

const STATUS_ICON: Record<StageStatus, LucideIcon | null> = {
  idle: Circle,
  running: Loader2,
  done: Check,
  flagged: AlertTriangle,
  rejected: XCircle,
}

export default function PipelineSidebar({
  onEnter,
}: {
  onEnter?: () => void
}) {
  const [collapsed, setCollapsed] = useState(false)
  const stages = usePipelineStore((s) => s.stages)
  const activeStage = usePipelineStore((s) => s.activeStage)
  const setActiveStage = usePipelineStore((s) => s.setActiveStage)
  const running = usePipelineStore((s) => s.running)
  const socketConnected = usePipelineStore((s) => s.socketConnected)
  const pairs = usePipelineStore((s) => s.pairs)

  const verifiedCount = pairs.filter((p) => p.verification?.verdict === 'pass').length
  const flaggedCount = pairs.filter((p) => p.verification?.verdict === 'flag').length

  return (
    <motion.aside
      animate={{ width: collapsed ? 64 : 280 }}
      transition={{ type: 'spring', stiffness: 260, damping: 30 }}
      className="relative z-20 h-full shrink-0 border-r border-border bg-sidebar/80 backdrop-blur-xl"
    >
      <div className="flex h-full flex-col">
        {/* Brand row */}
        <div className="flex items-center gap-2 px-3 py-4 border-b border-border">
          <button
            onClick={onEnter}
            className="flex items-center gap-2 min-w-0 group"
            aria-label="Back to hero"
          >
            <div className="size-7 rounded-md bg-gradient-to-br from-agent to-emerald-400 flex items-center justify-center shrink-0">
              <span className="text-xs font-bold text-accent-foreground">A</span>
            </div>
            {!collapsed && (
              <div className="min-w-0">
                <div className="text-sm font-semibold leading-tight truncate">AR2-DDCQG</div>
                <div className="text-[10px] text-muted-foreground leading-tight truncate">
                  diagram → Q&A
                </div>
              </div>
            )}
          </button>
          <button
            onClick={() => setCollapsed((c) => !c)}
            className="ml-auto size-7 inline-flex items-center justify-center rounded-md text-muted-foreground hover:text-foreground hover:bg-foreground/5 transition"
            aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          >
            {collapsed ? <ChevronRight className="size-4" /> : <ChevronLeft className="size-4" />}
          </button>
        </div>

        {/* Pipeline nav */}
        <nav className="flex-1 px-2 py-3 overflow-y-auto no-scrollbar">
          {!collapsed && (
            <div className="px-2 pb-2 text-[10px] uppercase tracking-wider text-muted-foreground/70">
              Pipeline
            </div>
          )}
          <ul className="space-y-1 relative">
            {PIPELINE_STAGES.map((stage, idx) => (
              <SidebarItem
                key={stage.id}
                stage={stage}
                index={idx}
                collapsed={collapsed}
                status={stages[stage.id].status}
                active={activeStage === stage.id}
                onClick={() => setActiveStage(stage.id)}
              />
            ))}
          </ul>
        </nav>

        {/* Run footer */}
        {!collapsed && (
          <div className="border-t border-border p-3 space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Connection</span>
              <span
                className={cn(
                  'flex items-center gap-1.5 font-medium',
                  socketConnected ? 'text-emerald-400' : 'text-muted-foreground',
                )}
              >
                <span
                  className={cn(
                    'size-1.5 rounded-full',
                    socketConnected ? 'bg-emerald-400 animate-pulse' : 'bg-muted-foreground/40',
                  )}
                />
                {socketConnected ? 'live' : 'offline'}
              </span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Run</span>
              <span
                className={cn(
                  'font-medium',
                  running ? 'text-agent' : 'text-muted-foreground',
                )}
              >
                {running ? 'in progress' : 'idle'}
              </span>
            </div>
            {pairs.length > 0 && (
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Q&amp;A pairs</span>
                <span className="font-mono text-foreground">
                  <span className="text-emerald-400">{verifiedCount}</span>
                  {flaggedCount > 0 && (
                    <span className="text-amber-400"> · {flaggedCount}⚠</span>
                  )}
                  <span className="text-muted-foreground"> / {pairs.length}</span>
                </span>
              </div>
            )}
          </div>
        )}
      </div>
    </motion.aside>
  )
}

function SidebarItem({
  stage,
  index,
  collapsed,
  status,
  active,
  onClick,
}: {
  stage: StageMeta
  index: number
  collapsed: boolean
  status: StageStatus
  active: boolean
  onClick: () => void
}) {
  const Icon = ICONS[stage.icon] ?? Circle
  const StatusIcon = STATUS_ICON[status]
  const style = STATUS_STYLES[status]
  const running = status === 'running'

  return (
    <li className="relative">
      <button
        onClick={onClick}
        className={cn(
          'group relative w-full flex items-center gap-3 rounded-lg px-2 py-2 text-left transition',
          collapsed && 'justify-center',
        )}
        title={collapsed ? stage.label : undefined}
      >
        {/* Shared-layout active glow — physically slides between items */}
        {active && (
          <motion.div
            layoutId="sidebar-active-glow"
            className="absolute inset-0 rounded-lg bg-foreground/[0.05] ring-1 ring-agent/30 agent-glow"
            transition={{ type: 'spring', stiffness: 380, damping: 32 }}
          />
        )}

        {/* Status indicator dot */}
        <span className="relative z-10 flex items-center justify-center shrink-0">
          <span className={cn('absolute size-2 rounded-full', style.dot, running && 'animate-ping')} />
          <span className={cn('size-2 rounded-full', style.dot)} />
        </span>

        {/* Icon */}
        <span
          className={cn(
            'relative z-10 shrink-0 size-7 inline-flex items-center justify-center rounded-md transition',
            active ? 'text-agent' : 'text-muted-foreground group-hover:text-foreground',
          )}
        >
          <Icon className="size-4" />
        </span>

        {/* Label + status */}
        {!collapsed && (
          <span className="relative z-10 min-w-0 flex-1">
            <span className="block text-sm font-medium leading-tight truncate">
              {stage.label}
            </span>
            <span className={cn('block text-[11px] leading-tight truncate', style.label)}>
              {status === 'idle' && stage.agent}
              {status === 'running' && 'working…'}
              {status === 'done' && 'complete'}
              {status === 'flagged' && 'flagged'}
              {status === 'rejected' && 'rejected'}
            </span>
          </span>
        )}

        {/* Status icon at the right edge when expanded */}
        {!collapsed && StatusIcon && (
          <span className={cn('relative z-10 shrink-0', style.label)}>
            <StatusIcon className={cn('size-3.5', running && 'animate-spin')} />
          </span>
        )}
      </button>

      {/* Connector line to next stage */}
      {index < PIPELINE_STAGES.length - 1 && !collapsed && (
        <div className="ml-4 pl-1 h-2 border-l border-border/60" />
      )}
    </li>
  )
}
