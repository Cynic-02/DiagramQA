'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { useMemo } from 'react'
import { X, Terminal, Braces, Lightbulb, ShieldCheck } from 'lucide-react'
import { usePipelineStore } from '@/lib/store'
import { usePipelineStageStatus } from './use-stage-status'
import { getStageMeta } from '@/lib/bloom'
import { cn } from '@/lib/utils'

/**
 * Right Context/Log Drawer.
 *
 * Slides in when the user clicks on an active agent stage. Shows the agent's
 * "thought process": live JSON for extraction, agent thoughts/logs for other
 * stages, and verification metrics.
 */
export default function RightPanel() {
  const open = usePipelineStore((s) => s.rightPanelOpen)
  const setOpen = usePipelineStore((s) => s.setRightPanelOpen)
  const activeStage = usePipelineStore((s) => s.activeStage)
  const extraction = usePipelineStore((s) => s.extraction)
  const logs = usePipelineStore((s) => s.logs)
  const pairs = usePipelineStore((s) => s.pairs)
  const meta = getStageMeta(activeStage)

  const stageLogs = useMemo(
    () => logs.filter((l) => l.stage === activeStage).slice(-50),
    [logs, activeStage],
  )

  const activePairs = useMemo(
    () => pairs.filter((p) => p.verification !== null).slice(-5),
    [pairs],
  )

  return (
    <AnimatePresence initial={false}>
      {open && (
        <motion.aside
          key="right-panel"
          initial={{ width: 0, opacity: 0 }}
          animate={{ width: 320, opacity: 1 }}
          exit={{ width: 0, opacity: 0 }}
          transition={{ type: 'spring', stiffness: 260, damping: 30 }}
          className="relative z-20 h-full shrink-0 border-l border-border bg-sidebar/80 backdrop-blur-xl overflow-hidden"
        >
          <div className="h-full w-80 flex flex-col">
            {/* Header */}
            <div className="flex items-center gap-2 px-3 py-3 border-b border-border">
              {activeStage === 'extraction' && <Braces className="size-4 text-agent" />}
              {activeStage === 'verification' && <ShieldCheck className="size-4 text-agent" />}
              {activeStage === 'results' && <ShieldCheck className="size-4 text-agent" />}
              {(activeStage === 'upload' ||
                activeStage === 'question-generation' ||
                activeStage === 'answering') && (
                <Lightbulb className="size-4 text-agent" />
              )}
              <div className="min-w-0 flex-1">
                <div className="text-sm font-medium leading-tight truncate">
                  {meta.agent} thoughts
                </div>
                <div className="text-[10px] text-muted-foreground leading-tight truncate">
                  live context
                </div>
              </div>
              <button
                onClick={() => setOpen(false)}
                className="size-7 inline-flex items-center justify-center rounded-md text-muted-foreground hover:text-foreground hover:bg-foreground/5"
                aria-label="Close panel"
              >
                <X className="size-4" />
              </button>
            </div>

            {/* Body — switches based on active stage */}
            <div className="flex-1 overflow-y-auto no-scrollbar">
              {activeStage === 'extraction' && (
                <ExtractionContext extraction={extraction} logs={stageLogs} />
              )}
              {activeStage === 'question-generation' && (
                <LogsContext logs={stageLogs} title="Question Agent · reasoning stream" />
              )}
              {activeStage === 'answering' && (
                <LogsContext logs={stageLogs} title="Answer Agent · reasoning stream" />
              )}
              {activeStage === 'verification' && (
                <VerificationContext logs={stageLogs} pairs={activePairs} />
              )}
              {activeStage === 'results' && (
                <ResultsContext pairs={pairs} />
              )}
              {activeStage === 'upload' && (
                <EmptyContext message="Upload a diagram to begin. The Vision agent's parsing output will appear here." />
              )}
            </div>
          </div>
        </motion.aside>
      )}
    </AnimatePresence>
  )
}

// ── Extraction context: live JSON typing ──────────────────────────────────
function ExtractionContext({
  extraction,
  logs,
}: {
  extraction: import('@/lib/types').ExtractionResult | null
  logs: import('@/lib/types').AgentLogLine[]
}) {
  return (
    <div className="p-3 space-y-3">
      <div className="flex items-center gap-2 text-[10px] uppercase tracking-wider text-muted-foreground">
        <Terminal className="size-3" />
        agent log
      </div>
      <LogLines logs={logs} />

      {extraction && (
        <>
          <div className="flex items-center gap-2 text-[10px] uppercase tracking-wider text-muted-foreground pt-2">
            <Braces className="size-3" />
            extracted json
          </div>
          <pre className="text-[10px] font-mono leading-relaxed bg-background/60 border border-border rounded-lg p-2.5 overflow-x-auto text-foreground/80 max-h-80">
{JSON.stringify(
  {
    diagramType: extraction.diagramType,
    summary: extraction.summary,
    entities: extraction.entities.map((e) => ({
      id: e.id,
      label: e.label,
      type: e.type,
      position: e.position,
    })),
    relationships: extraction.relationships,
  },
  null,
  2,
)}
          </pre>
        </>
      )}
    </div>
  )
}

// ── Generic logs context ──────────────────────────────────────────────────
function LogsContext({
  logs,
  title,
}: {
  logs: import('@/lib/types').AgentLogLine[]
  title: string
}) {
  return (
    <div className="p-3 space-y-3">
      <div className="flex items-center gap-2 text-[10px] uppercase tracking-wider text-muted-foreground">
        <Terminal className="size-3" />
        {title}
      </div>
      <LogLines logs={logs} />
    </div>
  )
}

// ── Verification context ──────────────────────────────────────────────────
function VerificationContext({
  logs,
  pairs,
}: {
  logs: import('@/lib/types').AgentLogLine[]
  pairs: import('@/lib/types').QAPair[]
}) {
  return (
    <div className="p-3 space-y-3">
      <div className="flex items-center gap-2 text-[10px] uppercase tracking-wider text-muted-foreground">
        <Terminal className="size-3" />
        verdicts
      </div>
      {pairs.length === 0 && (
        <div className="text-xs text-muted-foreground/60">no verdicts yet</div>
      )}
      <div className="space-y-2">
        <AnimatePresence initial={false}>
          {pairs.map((p) => {
            const v = p.verification!
            const color =
              v.verdict === 'pass'
                ? '#7dd3a0'
                : v.verdict === 'flag'
                  ? '#facc15'
                  : '#f87171'
            return (
              <motion.div
                key={p.id}
                layout
                initial={{ opacity: 0, x: 8 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -8 }}
                className="rounded-lg border border-border bg-background/40 p-2.5 space-y-1.5"
              >
                <div className="flex items-center gap-2">
                  <span className="size-1.5 rounded-full" style={{ background: color }} />
                  <span className="text-[11px] font-mono uppercase tracking-wider" style={{ color }}>
                    {v.verdict}
                  </span>
                  <span className="text-[10px] text-muted-foreground/60 ml-auto">{p.id}</span>
                </div>
                <p className="text-[11px] text-foreground/80 leading-relaxed">{v.notes}</p>
                <div className="grid grid-cols-3 gap-1.5 text-[10px]">
                  <Metric label="correct" value={v.correct ? 1 : 0} color="#7dd3a0" binary />
                  <Metric label="clarity" value={1 - v.ambiguity} color="#5ee0c6" />
                  <Metric label="bloom" value={v.difficultyMatch} color="#a3e6d6" />
                </div>
              </motion.div>
            )
          })}
        </AnimatePresence>
      </div>

      <div className="flex items-center gap-2 text-[10px] uppercase tracking-wider text-muted-foreground pt-2">
        <Terminal className="size-3" />
        agent log
      </div>
      <LogLines logs={logs} />
    </div>
  )
}

// ── Results context ───────────────────────────────────────────────────────
function ResultsContext({ pairs }: { pairs: import('@/lib/types').QAPair[] }) {
  const pass = pairs.filter((p) => p.verification?.verdict === 'pass').length
  const flag = pairs.filter((p) => p.verification?.verdict === 'flag').length
  const regen = pairs.filter((p) => p.verification?.verdict === 'regenerate').length
  const avgConf =
    pairs.length > 0
      ? pairs.reduce((s, p) => s + (p.answer?.confidence ?? 0), 0) / pairs.length
      : 0

  return (
    <div className="p-3 space-y-3">
      <div className="flex items-center gap-2 text-[10px] uppercase tracking-wider text-muted-foreground">
        <ShieldCheck className="size-3" />
        run summary
      </div>
      <div className="space-y-2">
        <SummaryRow label="Total pairs" value={String(pairs.length)} />
        <SummaryRow label="Passed" value={String(pass)} color="#7dd3a0" />
        <SummaryRow label="Flagged" value={String(flag)} color="#facc15" />
        <SummaryRow label="Regenerated" value={String(regen)} color="#f87171" />
        <SummaryRow label="Avg confidence" value={`${Math.round(avgConf * 100)}%`} color="#5ee0c6" />
      </div>
    </div>
  )
}

function SummaryRow({ label, value, color }: { label: string; value: string; color?: string }) {
  return (
    <div className="flex items-center justify-between text-xs">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-mono font-medium" style={color ? { color } : undefined}>
        {value}
      </span>
    </div>
  )
}

// ── Log lines (shared) ────────────────────────────────────────────────────
function LogLines({ logs }: { logs: import('@/lib/types').AgentLogLine[] }) {
  return (
    <div className="rounded-lg bg-background/60 border border-border p-2.5 font-mono text-[10px] space-y-1 max-h-64 overflow-y-auto">
      <AnimatePresence initial={false}>
        {logs.map((l, i) => (
          <motion.div
            key={`${l.ts}-${i}`}
            initial={{ opacity: 0, x: -4 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex gap-2"
          >
            <span className="text-muted-foreground/50 shrink-0">
              {new Date(l.ts).toLocaleTimeString([], { hour12: false })}
            </span>
            <span
              className={cn(
                l.level === 'error' && 'text-red-400',
                l.level === 'warn' && 'text-amber-400',
                l.level === 'thought' && 'text-agent/80 italic',
                l.level === 'info' && 'text-foreground/70',
              )}
            >
              {l.text}
            </span>
          </motion.div>
        ))}
      </AnimatePresence>
      {logs.length === 0 && (
        <div className="text-muted-foreground/40">waiting for agent output…</div>
      )}
    </div>
  )
}

function Metric({
  label,
  value,
  color,
  binary,
}: {
  label: string
  value: number
  color: string
  binary?: boolean
}) {
  const pct = Math.round(value * 100)
  return (
    <div>
      <div className="flex justify-between text-[9px] mb-0.5">
        <span className="text-muted-foreground">{label}</span>
        <span style={{ color }}>{binary ? (value >= 1 ? 'yes' : 'no') : `${pct}%`}</span>
      </div>
      <div className="h-1 rounded-full bg-foreground/10 overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${pct}%` }}
          className="h-full rounded-full"
          style={{ background: color }}
        />
      </div>
    </div>
  )
}

function EmptyContext({ message }: { message: string }) {
  return (
    <div className="p-6 text-center">
      <div className="size-10 mx-auto rounded-full bg-foreground/5 flex items-center justify-center mb-3">
        <Lightbulb className="size-5 text-muted-foreground/40" />
      </div>
      <p className="text-xs text-muted-foreground/70 leading-relaxed">{message}</p>
    </div>
  )
}
