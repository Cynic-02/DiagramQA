'use client'

import { motion, AnimatePresence, useMotionValue, useTransform } from 'framer-motion'
import { useCallback, useRef, useState, useEffect } from 'react'
import { Upload, FileImage, X, Play, Loader2, ImageDown } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { usePipelineStore } from '@/lib/store'
import { useStartRun } from '@/hooks/use-pipeline-socket'
import { BloomSelector } from '@/components/bloom-selector'
import { toast } from 'sonner'

const ACCEPTED = ['image/png', 'image/jpeg', 'image/webp', 'image/gif', 'application/pdf']

export default function UploadView() {
  const [dragging, setDragging] = useState(false)
  const [screenDrag, setScreenDrag] = useState(false) // screen-wide overlay active
  const [loading, setLoading] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)
  const dragDepth = useRef(0)
  const diagram = usePipelineStore((s) => s.diagram)
  const setDiagram = usePipelineStore((s) => s.setDiagram)
  const bloom = usePipelineStore((s) => s.bloom)
  const questionCount = usePipelineStore((s) => s.questionCount)
  const setQuestionCount = usePipelineStore((s) => s.setQuestionCount)
  const running = usePipelineStore((s) => s.running)
  const startRun = useStartRun()

  // Spring-animated dropzone scale — shrinks slightly when a file hovers.
  const dropScale = useMotionValue(1)
  const dropSpring = useTransform(dropScale, (v) => `scale(${v})`)

  useEffect(() => {
    if (dragging) dropScale.set(0.96)
    else dropScale.set(1)
  }, [dragging, dropScale])

  const readFile = useCallback(
    (file: File) => {
      if (!ACCEPTED.includes(file.type) && !file.type.startsWith('image/')) {
        toast.error('Unsupported file type', {
          description: 'Please upload PNG, JPEG, WebP, GIF, or PDF.',
        })
        return
      }
      if (file.size > 12 * 1024 * 1024) {
        toast.error('File too large', { description: 'Maximum 12 MB.' })
        return
      }
      setLoading(true)
      const reader = new FileReader()
      reader.onload = () => {
        setDiagram({
          name: file.name,
          mimeType: file.type,
          dataUrl: String(reader.result),
        })
        setLoading(false)
      }
      reader.onerror = () => {
        toast.error('Could not read file')
        setLoading(false)
      }
      reader.readAsDataURL(file)
    },
    [setDiagram],
  )

  // Screen-wide drag overlay: listen on window so the user can drop anywhere.
  useEffect(() => {
    const onDragOver = (e: DragEvent) => {
      if (e.dataTransfer?.types?.includes('Files')) {
        e.preventDefault()
        setScreenDrag(true)
      }
    }
    const onDragLeave = (e: DragEvent) => {
      if (e.relatedTarget === null) setScreenDrag(false)
    }
    const onDrop = (e: DragEvent) => {
      e.preventDefault()
      setScreenDrag(false)
      setDragging(false)
      const f = e.dataTransfer?.files?.[0]
      if (f) readFile(f)
    }
    window.addEventListener('dragover', onDragOver)
    window.addEventListener('dragleave', onDragLeave)
    window.addEventListener('drop', onDrop)
    return () => {
      window.removeEventListener('dragover', onDragOver)
      window.removeEventListener('dragleave', onDragLeave)
      window.removeEventListener('drop', onDrop)
    }
  }, [readFile])

  const onRun = () => {
    if (!diagram) {
      toast.error('Upload a diagram first')
      return
    }
    startRun({
      diagram: { name: diagram.name, mimeType: diagram.mimeType, dataUrl: diagram.dataUrl },
      bloom,
      questionCount,
    })
    toast.success('Pipeline started', {
      description: `Running ${questionCount} questions at the "${bloom}" Bloom's level.`,
    })
  }

  return (
    <div className="h-full flex flex-col">
      {/* Screen-wide drag overlay */}
      <AnimatePresence>
        {screenDrag && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
            className="fixed inset-0 z-50 glass-strong flex items-center justify-center pointer-events-none"
          >
            <motion.div
              initial={{ scale: 0.9, y: 10 }}
              animate={{ scale: 1, y: 0 }}
              transition={{ type: 'spring', stiffness: 400, damping: 25 }}
              className="rounded-2xl border-2 border-dashed border-agent bg-agent/5 px-12 py-10 text-center"
            >
              <Upload className="size-10 mx-auto text-agent mb-3" />
              <div className="text-lg font-medium text-foreground">Drop to upload</div>
              <div className="text-xs text-muted-foreground mt-1">
                PNG · JPEG · WebP · GIF · PDF · max 12 MB
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex-1 overflow-y-auto">
        <div className="mx-auto max-w-4xl px-4 sm:px-8 py-8 sm:py-10 space-y-8">
          <header className="space-y-1">
            <h2 className="text-2xl font-semibold tracking-tight">Source Diagram</h2>
            <p className="text-sm text-muted-foreground">
              Upload an architecture diagram, flowchart, circuit diagram, or any visual
              schematic. The Vision agent will parse it into entities and relationships.
            </p>
          </header>

          {/* Dropzone — large dashed bounding box with spring physics */}
          <motion.div
            style={{ scale: dropSpring }}
            onDragOver={(e) => {
              e.preventDefault()
              setDragging(true)
            }}
            onDragLeave={() => setDragging(false)}
            onDrop={(e) => {
              e.preventDefault()
              setDragging(false)
              const f = e.dataTransfer.files?.[0]
              if (f) readFile(f)
            }}
            className={cnDrop(dragging)}
          >
            <input
              ref={inputRef}
              type="file"
              accept={ACCEPTED.join(',')}
              className="sr-only"
              aria-hidden
              tabIndex={-1}
              onChange={(e) => {
                const f = e.target.files?.[0]
                if (f) readFile(f)
                e.currentTarget.value = ''
              }}
            />

            <AnimatePresence mode="wait">
              {diagram ? (
                <motion.div
                  key="preview"
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  className="flex flex-col items-center gap-4 py-6"
                >
                  <div className="relative w-full max-w-md rounded-xl overflow-hidden border border-border bg-surface">
                    {diagram.mimeType === 'application/pdf' ? (
                      <div className="aspect-[4/3] flex flex-col items-center justify-center gap-3 text-muted-foreground">
                        <ImageDown className="size-10" />
                        <div className="text-sm">PDF diagram</div>
                        <div className="text-xs text-muted-foreground/70">{diagram.name}</div>
                      </div>
                    ) : (
                      <img
                        src={diagram.dataUrl}
                        alt={diagram.name}
                        className="w-full aspect-[4/3] object-contain bg-background"
                      />
                    )}
                    <button
                      onClick={() => setDiagram(null)}
                      className="absolute top-2 right-2 size-7 inline-flex items-center justify-center rounded-md bg-background/70 backdrop-blur hover:bg-background"
                      aria-label="Remove diagram"
                    >
                      <X className="size-4" />
                    </button>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <FileImage className="size-4 text-muted-foreground" />
                    <span className="font-mono text-xs">{diagram.name}</span>
                    <span className="text-muted-foreground text-xs">
                      · {Math.round((diagram.dataUrl.length * 0.75) / 1024)} KB
                    </span>
                  </div>
                </motion.div>
              ) : (
                <motion.button
                  key="dropzone"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  onClick={() => inputRef.current?.click()}
                  className="w-full py-20 flex flex-col items-center justify-center gap-4 text-center"
                >
                  <motion.div
                    animate={{
                      scale: dragging ? [1, 1.08, 1] : 1,
                      opacity: dragging ? 1 : 0.7,
                    }}
                    transition={{ duration: 1.4, repeat: dragging ? Infinity : 0 }}
                    className="size-16 rounded-full bg-foreground/[0.04] flex items-center justify-center"
                  >
                    {loading ? (
                      <Loader2 className="size-6 animate-spin text-muted-foreground" />
                    ) : (
                      <Upload className="size-6 text-agent" />
                    )}
                  </motion.div>
                  <div>
                    <div className="text-base font-medium">
                      Drop a diagram here, or click to browse
                    </div>
                    <div className="text-xs text-muted-foreground mt-1.5">
                      PNG · JPEG · WebP · GIF · PDF · max 12 MB
                    </div>
                  </div>
                </motion.button>
              )}
            </AnimatePresence>
          </motion.div>

          {/* Configuration */}
          <div className="grid gap-6 md:grid-cols-2">
            <div className="space-y-3">
              <div className="text-xs uppercase tracking-wider text-muted-foreground">
                Bloom&rsquo;s difficulty
              </div>
              <BloomSelector value={bloom} />
            </div>

            <div className="space-y-3">
              <div className="text-xs uppercase tracking-wider text-muted-foreground">
                Number of questions
              </div>
              <div className="flex items-center gap-2">
                {[2, 4, 6, 8].map((n) => (
                  <button
                    key={n}
                    onClick={() => setQuestionCount(n)}
                    className={
                      'size-9 rounded-md text-sm font-mono transition ' +
                      (questionCount === n
                        ? 'bg-agent text-accent-foreground'
                        : 'bg-surface text-muted-foreground hover:text-foreground hover:bg-surface-elevated')
                    }
                  >
                    {n}
                  </button>
                ))}
              </div>
              <div className="text-xs text-muted-foreground">
                More questions means longer verification loops.
              </div>
            </div>
          </div>

          {/* Primary action */}
          <div className="flex items-center justify-between pt-4 border-t border-border">
            <div className="text-xs text-muted-foreground">
              {diagram
                ? `Ready to run · ${questionCount} × "${bloom}" questions`
                : 'Upload a diagram to continue'}
            </div>
            <Button
              size="lg"
              disabled={!diagram || running}
              onClick={onRun}
              className="bg-agent text-accent-foreground hover:bg-agent/90"
            >
              {running ? (
                <>
                  <Loader2 className="mr-2 size-4 animate-spin" />
                  Running…
                </>
              ) : (
                <>
                  <Play className="mr-2 size-4" />
                  Run pipeline
                </>
              )}
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

function cnDrop(dragging: boolean): string {
  const base =
    'relative rounded-2xl border-2 border-dashed transition-colors min-h-[20rem] flex items-center justify-center'
  return dragging
    ? `${base} border-agent bg-agent/[0.05]`
    : `${base} border-border bg-surface/40 hover:border-foreground/20`
}
