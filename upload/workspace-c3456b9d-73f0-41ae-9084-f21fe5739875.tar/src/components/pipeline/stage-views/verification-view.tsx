'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { useMemo, useState, useEffect } from 'react'
import {
  ShieldCheck,
  Loader2,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  XCircle,
  Zap,
} from 'lucide-react'
import { usePipelineStore } from '@/lib/store'
import { usePipelineStageStatus } from '@/components/pipeline/use-stage-status'
import { getBloomMeta } from '@/lib/bloom'
import type { QAPair, VerificationResult } from '@/lib/types'

const VERDICT_META = {
  pass: { icon: CheckCircle2, label: 'Verified', color: '#7dd3a0' },
  flag: { icon: AlertTriangle, label: 'Flagged', color: '#facc15' },
  regenerate: { icon: RefreshCw, label: 'Rejected', color: '#f87171' },
} as const

export default function VerificationView() {
  const pairs = usePipelineStore((s) => s.pairs)
  const status = usePipelineStageStatus('verification')

  const verified = pairs.filter((p) => p.verification !== null)
  const pass = verified.filter((p) => p.verification?.verdict === 'pass').length
  const flag = verified.filter((p) => p.verification?.verdict === 'flag').length
  const regen = verified.filter((p) => p.verification?.verdict === 'regenerate').length

  // The "currently clashing" pair — the most recent one being verified.
  const activeIdx = useMemo(() => {
    if (status === 'running') {
      // Find the first pair that has an answer but no verification yet.
      const idx = pairs.findIndex((p) => p.answer && !p.verification)
      if (idx !== -1) return idx
    }
    // Otherwise, show the most recently verified pair.
    for (let i = pairs.length - 1; i >= 0; i--) {
      if (pairs[i].verification) return i
    }
    return -1
  }, [pairs, status])

  const activePair = activeIdx >= 0 ? pairs[activeIdx] : null

  return (
    <div className="h-full flex flex-col">
      <div className="flex-1 overflow-y-auto">
        <div className="mx-auto max-w-5xl px-4 sm:px-8 py-8 space-y-6">
          <header className="space-y-1">
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <ShieldCheck className="size-3.5" />
              Verify Agent
            </div>
            <h2 className="text-2xl font-semibold tracking-tight">Verification Loop</h2>
            <p className="text-sm text-muted-foreground max-w-2xl">
              The Verify agent pits each question against its independent answer.
              Passed pairs merge into a verified artifact; rejected pairs shatter
              and loop back to the Question agent.
            </p>
          </header>

          {/* Summary cards */}
          <div className="grid grid-cols-3 gap-3">
            <SummaryCard label="Verified" value={pass} color="#7dd3a0" icon={CheckCircle2} />
            <SummaryCard label="Flagged" value={flag} color="#facc15" icon={AlertTriangle} />
            <SummaryCard label="Rejected" value={regen} color="#f87171" icon={RefreshCw} />
          </div>

          {/* The Clash arena — shows the active pair facing off */}
          {activePair ? (
            <ClashArena pair={activePair} isVerifying={status === 'running' && !activePair.verification} />
          ) : (
            <div className="rounded-xl border border-dashed border-border bg-surface/30 p-12 text-center">
              <ShieldCheck className="size-8 mx-auto text-muted-foreground/40" />
              <div className="mt-3 text-sm text-muted-foreground">
                Verification begins once the Answer agent has produced results.
              </div>
            </div>
          )}

          {/* All verified pairs (compact list) */}
          {verified.length > 0 && (
            <div>
              <div className="text-xs uppercase tracking-wider text-muted-foreground mb-3">
                All verdicts
              </div>
              <div className="space-y-2">
                <AnimatePresence initial={false}>
                  {pairs.map((p, i) => (
                    <VerdictRow key={p.id} pair={p} index={i} active={i === activeIdx} />
                  ))}
                </AnimatePresence>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

// ── The Clash Arena ───────────────────────────────────────────────────────
function ClashArena({
  pair,
  isVerifying,
}: {
  pair: QAPair
  isVerifying: boolean
}) {
  const v = pair.verification
  const verdict = v?.verdict
  const meta = getBloomMeta(pair.question.bloom)

  return (
    <div className="relative rounded-2xl border border-border bg-surface/30 p-6 sm:p-10 overflow-hidden min-h-[24rem]">
      {/* Arena background grid */}
      <div
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage:
            'linear-gradient(to right, var(--foreground) 1px, transparent 1px), linear-gradient(to bottom, var(--foreground) 1px, transparent 1px)',
          backgroundSize: '32px 32px',
        }}
      />

      {/* Versus label */}
      <div className="relative flex items-center justify-center mb-6">
        <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground font-mono">
          {isVerifying ? 'verifying' : verdict === 'pass' ? 'merged' : verdict === 'regenerate' ? 'shattered' : 'reviewing'}
        </span>
      </div>

      {/* The two cards */}
      <div className="relative grid sm:grid-cols-2 gap-4 sm:gap-8 items-stretch">
        <ClashCard
          side="question"
          label="Question"
          accent={meta.color}
          text={pair.question.question}
          meta={
            <span
              className="text-[10px] font-mono px-1.5 py-0.5 rounded"
              style={{ background: `${meta.color}22`, color: meta.color }}
            >
              {meta.label}
            </span>
          }
          verdict={verdict}
          isVerifying={isVerifying}
        />

        <ClashCard
          side="answer"
          label="Independent Answer"
          accent="#7dd3a0"
          text={pair.answer?.answer ?? 'deriving…'}
          meta={
            pair.answer ? (
              <span className="text-[10px] font-mono text-muted-foreground">
                conf {(pair.answer.confidence * 100).toFixed(0)}%
              </span>
            ) : null
          }
          verdict={verdict}
          isVerifying={isVerifying || !pair.answer}
        />
      </div>

      {/* Laser sweep — runs while verifying */}
      <AnimatePresence>
        {isVerifying && (
          <motion.div
            initial={{ x: '-100%' }}
            animate={{ x: '100%' }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1.2, repeat: Infinity, ease: 'linear' }}
            className="absolute inset-y-0 w-32 pointer-events-none"
            style={{
              background:
                'linear-gradient(90deg, transparent, var(--agent-glow), transparent)',
              mixBlendMode: 'screen',
            }}
          />
        )}
      </AnimatePresence>

      {/* Verdict overlay */}
      <AnimatePresence>
        {v && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            className="relative mt-6 flex items-center justify-center"
          >
            <VerdictBadge verdict={v} />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

function ClashCard({
  side,
  label,
  accent,
  text,
  meta,
  verdict,
  isVerifying,
}: {
  side: 'question' | 'answer'
  label: string
  accent: string
  text: string
  meta: React.ReactNode
  verdict?: VerificationResult['verdict']
  isVerifying: boolean
}) {
  // Animation states based on verdict
  const cardColor =
    verdict === 'pass'
      ? '#7dd3a0'
      : verdict === 'regenerate'
        ? '#f87171'
        : verdict === 'flag'
          ? '#facc15'
          : accent

  const shakeX =
    verdict === 'regenerate' ? [-10, 10, -10, 10, -6, 6, 0] : 0

  return (
    <motion.div
      initial={
        side === 'question'
          ? { opacity: 0, x: -40, rotateY: -15 }
          : { opacity: 0, x: 40, rotateY: 15 }
      }
      animate={{
        opacity: 1,
        x: shakeX,
        rotateY: 0,
        scale: verdict === 'pass' ? [1, 1.02, 1] : 1,
      }}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{
        type: 'spring',
        stiffness: 300,
        damping: 22,
        x: { duration: 0.4 },
      }}
      className="relative rounded-xl border bg-surface/80 backdrop-blur p-5"
      style={{
        borderColor: `${cardColor}66`,
        boxShadow:
          verdict === 'pass'
            ? `0 0 0 1px ${cardColor}, 0 0 32px -4px ${cardColor}80`
            : `0 0 0 1px ${cardColor}40`,
      }}
    >
      {/* Card label */}
      <div className="flex items-center gap-2 mb-3">
        <span className="text-[10px] uppercase tracking-wider font-mono" style={{ color: cardColor }}>
          {label}
        </span>
        {meta}
      </div>
      {/* Card text */}
      <p className="text-sm leading-relaxed text-foreground/90 min-h-[3rem]">{text}</p>

      {/* Shatter effect on regenerate */}
      {verdict === 'regenerate' && (
        <motion.div
          initial={{ opacity: 0.8, scale: 0.5 }}
          animate={{ opacity: 0, scale: 1.5 }}
          transition={{ duration: 0.6 }}
          className="absolute inset-0 pointer-events-none"
        >
          {Array.from({ length: 8 }).map((_, i) => (
            <motion.div
              key={i}
              initial={{ x: 0, y: 0, opacity: 0.8 }}
              animate={{
                x: (Math.random() - 0.5) * 120,
                y: (Math.random() - 0.5) * 120,
                opacity: 0,
                rotate: (Math.random() - 0.5) * 180,
              }}
              transition={{ duration: 0.6 }}
              className="absolute top-1/2 left-1/2 size-2 rounded-sm"
              style={{ background: '#f87171' }}
            />
          ))}
        </motion.div>
      )}

      {/* Glow pulse while verifying */}
      {isVerifying && (
        <motion.div
          animate={{ opacity: [0.2, 0.5, 0.2] }}
          transition={{ duration: 1.2, repeat: Infinity }}
          className="absolute inset-0 rounded-xl pointer-events-none"
          style={{ boxShadow: `inset 0 0 24px -4px ${accent}` }}
        />
      )}
    </motion.div>
  )
}

function VerdictBadge({ verdict: v }: { verdict: VerificationResult }) {
  const meta = VERDICT_META[v.verdict]
  const Icon = meta.icon
  return (
    <motion.div
      initial={{ opacity: 0, y: 10, scale: 0.9 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ type: 'spring', stiffness: 400, damping: 20 }}
      className="inline-flex items-center gap-2 px-4 py-2 rounded-full border"
      style={{
        background: `${meta.color}11`,
        borderColor: `${meta.color}44`,
      }}
    >
      <Icon className="size-4" style={{ color: meta.color }} />
      <span className="text-sm font-medium" style={{ color: meta.color }}>
        {meta.label}
      </span>
      <span className="text-xs text-muted-foreground ml-2">{v.notes}</span>
    </motion.div>
  )
}

// ── Summary + Verdict row ─────────────────────────────────────────────────
function SummaryCard({
  label,
  value,
  color,
  icon: Icon,
}: {
  label: string
  value: number
  color: string
  icon: typeof ShieldCheck
}) {
  return (
    <div
      className="rounded-xl border p-4"
      style={{ background: `${color}11`, borderColor: `${color}33` }}
    >
      <div className="flex items-center gap-2">
        <Icon className="size-4" style={{ color }} />
        <span className="text-xs text-muted-foreground">{label}</span>
      </div>
      <div className="mt-2 text-2xl font-semibold tabular-nums" style={{ color }}>
        {value}
      </div>
    </div>
  )
}

function VerdictRow({
  pair,
  index,
  active,
}: {
  pair: QAPair
  index: number
  active: boolean
}) {
  const v = pair.verification
  if (!v) {
    return (
      <div className="rounded-lg border border-dashed border-border bg-surface/20 p-3 flex items-center gap-3 text-xs text-muted-foreground">
        <span className="font-mono">#{String(index + 1).padStart(2, '0')}</span>
        <span>awaiting verification…</span>
      </div>
    )
  }
  const meta = getBloomMeta(pair.question.bloom)
  const vMeta = VERDICT_META[v.verdict]
  const VIcon = vMeta.icon
  return (
    <motion.div
      layout
      initial={{ opacity: 0, x: -8 }}
      animate={{ opacity: 1, x: 0 }}
      className={
        'rounded-lg border bg-surface/40 p-3 flex items-center gap-3 ' +
        (active ? 'border-agent/40 agent-glow' : 'border-border')
      }
    >
      <span className="font-mono text-[10px] text-muted-foreground shrink-0">
        #{String(index + 1).padStart(2, '0')}
      </span>
      <span
        className="text-[10px] font-mono px-1.5 py-0.5 rounded shrink-0"
        style={{ background: `${meta.color}22`, color: meta.color }}
      >
        {meta.label}
      </span>
      <p className="text-xs text-foreground/80 truncate flex-1">{pair.question.question}</p>
      <VIcon className="size-3.5 shrink-0" style={{ color: vMeta.color }} />
      {pair.attempts > 0 && (
        <span className="text-[10px] text-amber-400 shrink-0">v{pair.attempts + 1}</span>
      )}
    </motion.div>
  )
}
