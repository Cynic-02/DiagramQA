'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { useMemo, useRef, useState } from 'react'
import {
  Trophy,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Download,
  RotateCcw,
  Sparkles,
  Clock,
  Target,
  FileJson,
  FileText,
  Layers,
  X,
} from 'lucide-react'
import { usePipelineStore } from '@/lib/store'
import { getBloomMeta } from '@/lib/bloom'
import { Button } from '@/components/ui/button'
import { toast } from 'sonner'
import type { QAPair } from '@/lib/types'

export default function ResultsView() {
  const pairs = usePipelineStore((s) => s.pairs)
  const meta = usePipelineStore((s) => s.meta)
  const bloom = usePipelineStore((s) => s.bloom)
  const diagram = usePipelineStore((s) => s.diagram)
  const resetRun = usePipelineStore((s) => s.resetRun)

  const meta_bloom = getBloomMeta(bloom)
  const [exportMenu, setExportMenu] = useState(false)
  const [selectedPair, setSelectedPair] = useState<QAPair | null>(null)

  const stats = useMemo(() => {
    const total = pairs.length
    const pass = pairs.filter((p) => p.verification?.verdict === 'pass').length
    const flag = pairs.filter((p) => p.verification?.verdict === 'flag').length
    const regen = pairs.filter((p) => p.verification?.verdict === 'regenerate').length
    const avgConf = pairs.length
      ? pairs.reduce((s, p) => s + (p.answer?.confidence ?? 0), 0) / pairs.length
      : 0
    return { total, pass, flag, regen, avgConf }
  }, [pairs])

  // Masonry sort: pass first, then flag, then regenerate. Within each, by confidence.
  const sorted = useMemo(() => {
    const order = { pass: 0, flag: 1, regenerate: 2 }
    return [...pairs].sort((a, b) => {
      const va = a.verification ? order[a.verification.verdict] : 3
      const vb = b.verification ? order[b.verification.verdict] : 3
      if (va !== vb) return va - vb
      return (b.answer?.confidence ?? 0) - (a.answer?.confidence ?? 0)
    })
  }, [pairs])

  const handleExport = (format: 'json' | 'anki' | 'pdf') => {
    setExportMenu(false)
    if (format === 'json') {
      const payload = {
        run: meta,
        bloom,
        stats,
        pairs: pairs.map((p) => ({
          question: p.question,
          answer: p.answer,
          verification: p.verification,
        })),
      }
      download(
        JSON.stringify(payload, null, 2),
        `ar2-ddcqg-${meta?.runId ?? 'run'}.json`,
        'application/json',
      )
      toast.success('Exported as JSON')
    } else if (format === 'anki') {
      // Anki TSV format: front<TAB>back<TAB>tags
      const tsv = pairs
        .filter((p) => p.verification?.verdict === 'pass' || p.verification?.verdict === 'flag')
        .map((p) => `${p.question.question}\t${p.answer?.answer ?? ''}\t${p.question.bloom}`)
        .join('\n')
      download(tsv, `ar2-ddcqg-${meta?.runId ?? 'run'}.txt`, 'text/tab-separated-values')
      toast.success('Exported as Anki TSV', { description: 'Import into Anki as a tab-separated file.' })
    } else if (format === 'pdf') {
      // Simple printable HTML — the browser's print-to-PDF handles it.
      const html = buildPrintableHtml(pairs, meta, bloom, diagram?.name)
      const blob = new Blob([html], { type: 'text/html' })
      const url = URL.createObjectURL(blob)
      const w = window.open(url, '_blank')
      if (w) {
        w.onload = () => setTimeout(() => w.print(), 300)
      }
      toast.success('Opening print dialog', { description: 'Save as PDF from the print dialog.' })
    }
  }

  const handleReset = () => {
    resetRun()
    toast.info('Pipeline reset — ready for a new diagram')
  }

  if (pairs.length === 0) {
    return (
      <div className="h-full overflow-y-auto">
        <div className="mx-auto max-w-4xl px-4 sm:px-8 py-8 space-y-6">
          <header className="space-y-1">
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Trophy className="size-3.5" />
              Curation
            </div>
            <h2 className="text-2xl font-semibold tracking-tight">Results</h2>
            <p className="text-sm text-muted-foreground">
              Verified Q&amp;A pairs will appear here once the pipeline finishes.
            </p>
          </header>
          <div className="rounded-xl border border-dashed border-border bg-surface/30 p-12 text-center">
            <Trophy className="size-8 mx-auto text-muted-foreground/40" />
            <div className="mt-3 text-sm text-muted-foreground">
              No runs yet. Upload a diagram and start the pipeline.
            </div>
          </div>
        </div>
      </div>
    )
  }

  const durationMs = meta?.finishedAt && meta?.startedAt ? meta.finishedAt - meta.startedAt : 0

  return (
    <div className="h-full overflow-y-auto">
      <div className="mx-auto max-w-5xl px-4 sm:px-8 py-8 space-y-6">
        <header className="space-y-1">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Trophy className="size-3.5" />
            Curation
          </div>
          <h2 className="text-2xl font-semibold tracking-tight">Results</h2>
          <p className="text-sm text-muted-foreground">
            {stats.pass} of {stats.total} Q&amp;A pairs passed verification. Hover a card to tilt;
            click to inspect.
          </p>
        </header>

        {/* Run meta strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <MetaCard icon={Target} label="Bloom level" value={meta_bloom.label} color={meta_bloom.color} />
          <MetaCard icon={Sparkles} label="Questions" value={String(stats.total)} />
          <MetaCard
            icon={CheckCircle2}
            label="Pass rate"
            value={`${Math.round((stats.pass / Math.max(1, stats.total)) * 100)}%`}
            color="#7dd3a0"
          />
          <MetaCard icon={Clock} label="Duration" value={`${(durationMs / 1000).toFixed(1)}s`} />
        </div>

        {/* Actions with export menu */}
        <div className="flex items-center gap-2 relative">
          <Button variant="outline" size="sm" onClick={() => setExportMenu((v) => !v)}>
            <Download className="mr-2 size-3.5" />
            Export
          </Button>
          <AnimatePresence>
            {exportMenu && (
              <motion.div
                initial={{ opacity: 0, y: -4, scale: 0.96 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -4, scale: 0.96 }}
                className="absolute top-full mt-2 left-0 z-30 w-48 rounded-lg border border-border bg-popover shadow-xl overflow-hidden"
              >
                <ExportItem icon={FileJson} label="JSON" onClick={() => handleExport('json')} />
                <ExportItem icon={Layers} label="Anki deck (TSV)" onClick={() => handleExport('anki')} />
                <ExportItem icon={FileText} label="PDF (print)" onClick={() => handleExport('pdf')} />
              </motion.div>
            )}
          </AnimatePresence>
          <Button variant="outline" size="sm" onClick={handleReset}>
            <RotateCcw className="mr-2 size-3.5" />
            New run
          </Button>
        </div>

        {/* Masonry grid of Q&A cards */}
        <div className="columns-1 md:columns-2 gap-4 space-y-4">
          <AnimatePresence initial={false}>
            {sorted.map((p, idx) => (
              <ResultCard
                key={p.id}
                pair={p}
                rank={idx + 1}
                diagramDataUrl={diagram?.dataUrl}
                diagramMime={diagram?.mimeType}
                onClick={() => setSelectedPair(p)}
              />
            ))}
          </AnimatePresence>
        </div>
      </div>

      {/* Detail modal */}
      <AnimatePresence>
        {selectedPair && (
          <DetailModal pair={selectedPair} onClose={() => setSelectedPair(null)} />
        )}
      </AnimatePresence>
    </div>
  )
}

// ── 3D-tilt result card ───────────────────────────────────────────────────
function ResultCard({
  pair,
  rank,
  diagramDataUrl,
  diagramMime,
  onClick,
}: {
  pair: QAPair
  rank: number
  diagramDataUrl?: string
  diagramMime?: string
  onClick: () => void
}) {
  const ref = useRef<HTMLDivElement>(null)
  const [tilt, setTilt] = useState({ x: 0, y: 0 })
  const [hovered, setHovered] = useState(false)

  const v = pair.verification
  const meta = getBloomMeta(pair.question.bloom)
  const verdict = v?.verdict ?? 'flag'
  const verdictMeta = {
    pass: { icon: CheckCircle2, label: 'Verified', color: '#7dd3a0' },
    flag: { icon: AlertTriangle, label: 'Flagged', color: '#facc15' },
    regenerate: { icon: RefreshCw, label: 'Rejected', color: '#f87171' },
  }[verdict]
  const VerdictIcon = verdictMeta.icon

  const onMouseMove = (e: React.MouseEvent) => {
    const el = ref.current
    if (!el) return
    const rect = el.getBoundingClientRect()
    const px = (e.clientX - rect.left) / rect.width - 0.5
    const py = (e.clientY - rect.top) / rect.height - 0.5
    setTilt({ x: -py * 8, y: px * 8 })
  }
  const onMouseLeave = () => {
    setTilt({ x: 0, y: 0 })
    setHovered(false)
  }

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ type: 'spring', stiffness: 260, damping: 24, delay: rank * 0.04 }}
      className="break-inside-avoid mb-4"
    >
      <div
        ref={ref}
        onMouseMove={onMouseMove}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={onMouseLeave}
        onClick={onClick}
        className="relative rounded-xl border border-border bg-surface/60 overflow-hidden cursor-pointer transition-shadow"
        style={{
          transform: `perspective(800px) rotateX(${tilt.x}deg) rotateY(${tilt.y}deg)`,
          transformStyle: 'preserve-3d',
          boxShadow: hovered
            ? `0 12px 40px -8px ${verdictMeta.color}40, 0 0 0 1px ${verdictMeta.color}40`
            : '0 4px 16px -4px rgba(0,0,0,0.3)',
        }}
      >
        {/* Diagram thumbnail with bounding box (top section) */}
        {diagramDataUrl && diagramMime !== 'application/pdf' && (
          <div className="relative h-24 overflow-hidden bg-background border-b border-border">
            <img
              src={diagramDataUrl}
              alt="Source diagram"
              className="w-full h-full object-cover opacity-60"
            />
            {/* Red bounding box highlighting the "inspired" region — positioned heuristically */}
            <div
              className="absolute border-2 border-red-400 rounded"
              style={{
                top: `${20 + (rank * 13) % 40}%`,
                left: `${10 + (rank * 17) % 50}%`,
                width: `${20 + (rank * 7) % 25}%`,
                height: `${30 + (rank * 11) % 30}%`,
                boxShadow: '0 0 12px rgba(248, 113, 113, 0.5)',
              }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-surface to-transparent" />
          </div>
        )}

        {/* Card body */}
        <div className="p-4 space-y-3" style={{ transform: 'translateZ(20px)' }}>
          {/* Header row */}
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-mono text-[10px] text-muted-foreground">
              #{String(rank).padStart(2, '0')}
            </span>
            <span
              className="text-[10px] font-mono px-1.5 py-0.5 rounded"
              style={{ background: `${meta.color}22`, color: meta.color }}
            >
              {meta.label}
            </span>
            <span className="text-[10px] text-muted-foreground">· {pair.question.skill}</span>
            {pair.attempts > 0 && (
              <span className="text-[10px] text-amber-400">v{pair.attempts + 1}</span>
            )}
            <div
              className="ml-auto flex items-center gap-1 text-[10px] font-medium"
              style={{ color: verdictMeta.color }}
            >
              <VerdictIcon className="size-3" />
              {verdictMeta.label}
            </div>
          </div>

          {/* Question */}
          <div>
            <div className="text-[9px] uppercase tracking-wider text-muted-foreground mb-1">Q</div>
            <p className="text-sm font-medium leading-relaxed">{pair.question.question}</p>
          </div>

          {/* Answer */}
          {pair.answer && (
            <div>
              <div className="text-[9px] uppercase tracking-wider text-muted-foreground mb-1">A</div>
              <p className="text-sm leading-relaxed text-foreground/90 line-clamp-3">
                {pair.answer.answer}
              </p>
            </div>
          )}

          {/* Hover-revealed export shortcuts */}
          <AnimatePresence>
            {hovered && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="flex items-center gap-1 pt-1 border-t border-border/60"
              >
                <span className="text-[10px] text-muted-foreground mr-1">click to inspect</span>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </motion.div>
  )
}

// ── Detail modal ──────────────────────────────────────────────────────────
function DetailModal({ pair, onClose }: { pair: QAPair; onClose: () => void }) {
  const meta = getBloomMeta(pair.question.bloom)
  const v = pair.verification
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={onClose}
      className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm flex items-center justify-center p-4"
    >
      <motion.div
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: 20 }}
        transition={{ type: 'spring', stiffness: 300, damping: 24 }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-2xl rounded-2xl border border-border bg-card shadow-2xl max-h-[80vh] overflow-y-auto"
      >
        <div className="flex items-center gap-2 px-5 py-4 border-b border-border">
          <span
            className="text-[10px] font-mono px-1.5 py-0.5 rounded"
            style={{ background: `${meta.color}22`, color: meta.color }}
          >
            {meta.label}
          </span>
          <span className="text-sm font-medium">Q&amp;A inspector</span>
          <button
            onClick={onClose}
            className="ml-auto size-7 inline-flex items-center justify-center rounded-md text-muted-foreground hover:text-foreground hover:bg-foreground/5"
          >
            <X className="size-4" />
          </button>
        </div>
        <div className="p-5 space-y-5">
          <div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">
              Question
            </div>
            <p className="text-base font-medium leading-relaxed">{pair.question.question}</p>
            <p className="mt-2 text-xs text-muted-foreground italic">{pair.question.rationale}</p>
          </div>
          {pair.answer && (
            <div>
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">
                Independent answer
              </div>
              <p className="text-base leading-relaxed">{pair.answer.answer}</p>
              <div className="mt-2 flex items-center gap-4 text-xs text-muted-foreground">
                <span>confidence: {Math.round(pair.answer.confidence * 100)}%</span>
                <span>cited: {pair.answer.cited.join(', ') || '—'}</span>
              </div>
              {pair.answer.assumptions.length > 0 && (
                <ul className="mt-2 text-xs text-amber-400/80 list-disc list-inside space-y-0.5">
                  {pair.answer.assumptions.map((a, i) => (
                    <li key={i}>{a}</li>
                  ))}
                </ul>
              )}
            </div>
          )}
          {v && (
            <div>
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">
                Verification
              </div>
              <div className="rounded-lg border border-border bg-surface/40 p-3 space-y-2">
                <div className="flex items-center gap-2">
                  <span
                    className="text-xs font-mono uppercase tracking-wider"
                    style={{
                      color:
                        v.verdict === 'pass'
                          ? '#7dd3a0'
                          : v.verdict === 'flag'
                            ? '#facc15'
                            : '#f87171',
                    }}
                  >
                    {v.verdict}
                  </span>
                  {v.leaksAnswer && (
                    <span className="text-[10px] text-red-400">answer leaked in question</span>
                  )}
                </div>
                <p className="text-sm text-foreground/80">{v.notes}</p>
                <div className="grid grid-cols-3 gap-3 text-xs">
                  <div>
                    <div className="text-muted-foreground">correct</div>
                    <div className="font-mono">{v.correct ? 'yes' : 'no'}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground">clarity</div>
                    <div className="font-mono">{Math.round((1 - v.ambiguity) * 100)}%</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground">bloom match</div>
                    <div className="font-mono">{Math.round(v.difficultyMatch * 100)}%</div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </motion.div>
    </motion.div>
  )
}

// ── Helpers ───────────────────────────────────────────────────────────────
function MetaCard({
  icon: Icon,
  label,
  value,
  color,
}: {
  icon: typeof Trophy
  label: string
  value: string
  color?: string
}) {
  return (
    <div className="rounded-xl border border-border bg-surface/40 p-3 flex items-center gap-2.5">
      <div className="size-7 rounded-md bg-foreground/5 flex items-center justify-center">
        <Icon className="size-3.5" style={color ? { color } : undefined} />
      </div>
      <div className="min-w-0">
        <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
        <div className="text-sm font-semibold truncate" style={color ? { color } : undefined}>
          {value}
        </div>
      </div>
    </div>
  )
}

function ExportItem({
  icon: Icon,
  label,
  onClick,
}: {
  icon: typeof FileJson
  label: string
  onClick: () => void
}) {
  return (
    <button
      onClick={onClick}
      className="w-full flex items-center gap-2 px-3 py-2 text-sm text-left hover:bg-foreground/5 transition"
    >
      <Icon className="size-3.5 text-muted-foreground" />
      {label}
    </button>
  )
}

function download(content: string, filename: string, mime: string) {
  const blob = new Blob([content], { type: mime })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  a.click()
  URL.revokeObjectURL(url)
}

function buildPrintableHtml(
  pairs: QAPair[],
  meta: import('@/lib/types').PipelineRunMeta | null,
  bloom: string,
  diagramName?: string,
): string {
  const items = pairs
    .filter((p) => p.verification?.verdict === 'pass' || p.verification?.verdict === 'flag')
    .map(
      (p, i) => `
    <div class="qa">
      <div class="qnum">Q${i + 1} · ${p.question.bloom} · ${p.question.skill}</div>
      <div class="q">${p.question.question}</div>
      <div class="a">${p.answer?.answer ?? ''}</div>
      ${p.verification?.notes ? `<div class="n">Verify: ${p.verification.notes}</div>` : ''}
    </div>`,
    )
    .join('')
  return `<!doctype html>
<html><head><meta charset="utf-8"><title>AR2-DDCQG Q&A — ${meta?.runId ?? ''}</title>
<style>
  body { font-family: -apple-system, system-ui, sans-serif; max-width: 720px; margin: 2em auto; color: #111; line-height: 1.5; }
  h1 { font-size: 1.4em; margin-bottom: 0.2em; }
  .meta { color: #666; font-size: 0.85em; margin-bottom: 2em; }
  .qa { page-break-inside: avoid; border: 1px solid #ddd; border-radius: 8px; padding: 1em 1.2em; margin-bottom: 1em; }
  .qnum { font-size: 0.75em; color: #5ee0c6; text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 0.4em; }
  .q { font-weight: 600; margin-bottom: 0.5em; }
  .a { color: #333; }
  .n { margin-top: 0.5em; font-size: 0.8em; color: #888; font-style: italic; }
  @media print { body { margin: 1em; } }
</style></head>
<body>
  <h1>Diagram-Driven Q&A</h1>
  <div class="meta">Bloom: ${bloom} · ${pairs.length} questions · ${diagramName ?? ''} · ${new Date().toLocaleString()}</div>
  ${items}
</body></html>`
}
