'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { useMemo } from 'react'
import { Sparkles, Loader2, Lock, Quote } from 'lucide-react'
import { usePipelineStore } from '@/lib/store'
import { usePipelineStageStatus } from '@/components/pipeline/use-stage-status'
import { getBloomMeta } from '@/lib/bloom'

export default function AnsweringView() {
  const pairs = usePipelineStore((s) => s.pairs)
  const logs = usePipelineStore((s) => s.logs)
  const status = usePipelineStageStatus('answering')

  const stageLogs = useMemo(
    () => logs.filter((l) => l.stage === 'answering').slice(-6),
    [logs],
  )
  const answered = pairs.filter((p) => p.answer !== null)

  return (
    <div className="space-y-6">
      <header className="space-y-1">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Sparkles className="size-3.5" />
          Answer Agent
        </div>
        <h2 className="text-2xl font-semibold tracking-tight">Answering</h2>
        <p className="text-sm text-muted-foreground">
          The Answer agent answers each question using only the diagram extraction —
          it never sees what the Question agent &ldquo;intended&rdquo;. This is the
          cross-check that catches leaked answers.
        </p>
      </header>

      {/* Anti-leak notice */}
      <div className="flex items-center gap-3 rounded-lg border border-agent/30 bg-agent/[0.04] p-3">
        <Lock className="size-4 text-agent shrink-0" />
        <div className="text-xs text-muted-foreground">
          <span className="text-foreground font-medium">Blind answering.</span> The
          Answer agent is isolated from the Question agent&rsquo;s reasoning. Any
          agreement between them is evidence the question is grounded, not leaking.
        </div>
      </div>

      <AnimatePresence mode="wait">
        {answered.length === 0 && status !== 'running' ? (
          <motion.div
            key="empty"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="rounded-xl border border-dashed border-border bg-surface/30 p-12 text-center"
          >
            <Sparkles className="size-8 mx-auto text-muted-foreground/40" />
            <div className="mt-3 text-sm text-muted-foreground">
              Waiting for the Question agent to finish.
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="list"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-3"
          >
            <AnimatePresence initial={false}>
              {pairs.map((p) => (
                <AnswerCard key={p.id} pair={p} />
              ))}
            </AnimatePresence>

            {status === 'running' && (
              <motion.div
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                className="rounded-lg border border-dashed border-agent/40 bg-agent/[0.03] p-3 flex items-center gap-2 text-sm text-agent"
              >
                <Loader2 className="size-4 animate-spin" />
                answering…
              </motion.div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Live logs */}
      {(status === 'running' || stageLogs.length > 0) && (
        <div className="rounded-lg bg-background/40 border border-border p-3 font-mono text-[11px] space-y-1 max-h-40 overflow-y-auto">
          <AnimatePresence initial={false}>
            {stageLogs.map((l, i) => (
              <motion.div
                key={`${l.ts}-${i}`}
                initial={{ opacity: 0, x: -4 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex gap-2"
              >
                <span className="text-muted-foreground/60">
                  {new Date(l.ts).toLocaleTimeString([], { hour12: false })}
                </span>
                <span
                  className={
                    l.level === 'error'
                      ? 'text-red-400'
                      : l.level === 'warn'
                        ? 'text-amber-400'
                        : l.level === 'thought'
                          ? 'text-agent/80'
                          : 'text-foreground/80'
                  }
                >
                  {l.text}
                </span>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  )
}

function AnswerCard({
  pair,
}: {
  pair: {
    id: string
    question: import('@/lib/types').GeneratedQuestion
    answer: import('@/lib/types').AnswerResult | null
  }
}) {
  const meta = getBloomMeta(pair.question.bloom)
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 12, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ type: 'spring', stiffness: 260, damping: 24 }}
      className="rounded-xl border border-border bg-surface/40 p-4"
    >
      {/* Question */}
      <div className="flex items-start gap-3 mb-3">
        <span className="text-[10px] font-mono px-1.5 py-0.5 rounded shrink-0"
          style={{ background: `${meta.color}22`, color: meta.color }}>
          {meta.label}
        </span>
        <p className="text-sm leading-relaxed text-foreground/90">{pair.question.question}</p>
      </div>

      {/* Answer */}
      <AnimatePresence mode="wait">
        {pair.answer ? (
          <motion.div
            key="answer"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="ml-1 border-l-2 border-agent/40 pl-3 space-y-2"
          >
            <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider text-agent">
              <Quote className="size-3" />
              Independent answer
            </div>
            <p className="text-sm leading-relaxed">{pair.answer.answer}</p>
            <div className="flex items-center gap-4 text-[11px] text-muted-foreground">
              <ConfidenceMeter value={pair.answer.confidence} />
              <span>
                cited:{' '}
                <span className="font-mono">
                  {pair.answer.cited.length ? pair.answer.cited.join(', ') : '—'}
                </span>
              </span>
              {pair.answer.assumptions.length > 0 && (
                <span className="text-amber-400">
                  {pair.answer.assumptions.length} assumption{pair.answer.assumptions.length > 1 ? 's' : ''}
                </span>
              )}
            </div>
            {pair.answer.assumptions.length > 0 && (
              <ul className="text-[11px] text-amber-400/80 list-disc list-inside space-y-0.5">
                {pair.answer.assumptions.map((a, i) => (
                  <li key={i}>{a}</li>
                ))}
              </ul>
            )}
          </motion.div>
        ) : (
          <motion.div
            key="pending"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="ml-1 flex items-center gap-2 text-xs text-muted-foreground"
          >
            <Loader2 className="size-3 animate-spin" />
            answering from diagram…
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  )
}

function ConfidenceMeter({ value }: { value: number }) {
  const pct = Math.round(value * 100)
  const color = value >= 0.7 ? '#7dd3a0' : value >= 0.4 ? '#facc15' : '#f87171'
  return (
    <div className="flex items-center gap-1.5">
      <span>confidence:</span>
      <div className="w-16 h-1.5 rounded-full bg-foreground/10 overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 0.5 }}
          className="h-full rounded-full"
          style={{ background: color }}
        />
      </div>
      <span className="font-mono" style={{ color }}>
        {pct}%
      </span>
    </div>
  )
}
