'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { useMemo } from 'react'
import { MessageSquarePlus, Loader2, Brain, Wand2 } from 'lucide-react'
import { usePipelineStore } from '@/lib/store'
import { usePipelineStageStatus } from '@/components/pipeline/use-stage-status'
import { getBloomMeta } from '@/lib/bloom'
import type { GeneratedQuestion } from '@/lib/types'

export default function QuestionGenerationView() {
  const pairs = usePipelineStore((s) => s.pairs)
  const logs = usePipelineStore((s) => s.logs)
  const bloom = usePipelineStore((s) => s.bloom)
  const questionCount = usePipelineStore((s) => s.questionCount)
  const status = usePipelineStageStatus('question-generation')

  const stageLogs = useMemo(
    () => logs.filter((l) => l.stage === 'question-generation').slice(-6),
    [logs],
  )
  const meta = getBloomMeta(bloom)
  const questions = pairs.map((p) => p.question)

  return (
    <div className="space-y-6">
      <header className="space-y-1">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <MessageSquarePlus className="size-3.5" />
          Question Agent
        </div>
        <h2 className="text-2xl font-semibold tracking-tight">Question Generation</h2>
        <p className="text-sm text-muted-foreground">
          The Question agent generates {questionCount} questions grounded in the
          extracted structure, conditioned on the{' '}
          <span className="text-foreground font-medium" style={{ color: meta.color }}>
            {meta.label}
          </span>{' '}
          Bloom&rsquo;s level.
        </p>
      </header>

      {/* Bloom context strip */}
      <div className="flex items-center gap-3 rounded-lg border border-border bg-surface/40 p-3">
        <Brain className="size-4" style={{ color: meta.color }} />
        <div className="text-sm">
          <span className="text-muted-foreground">Targeting:</span>{' '}
          <span className="font-medium" style={{ color: meta.color }}>
            {meta.label}
          </span>{' '}
          <span className="text-muted-foreground text-xs">· {meta.tagline}</span>
        </div>
        <div className="ml-auto flex gap-1">
          {meta.verbs.map((v) => (
            <span
              key={v}
              className="px-2 py-0.5 rounded-full bg-foreground/[0.05] text-[10px] font-mono text-muted-foreground"
            >
              {v}
            </span>
          ))}
        </div>
      </div>

      <AnimatePresence mode="wait">
        {questions.length === 0 && status !== 'running' ? (
          <motion.div
            key="empty"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="rounded-xl border border-dashed border-border bg-surface/30 p-12 text-center"
          >
            <Wand2 className="size-8 mx-auto text-muted-foreground/40" />
            <div className="mt-3 text-sm text-muted-foreground">
              No questions yet. Run the pipeline to start generation.
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="list"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-3"
          >
            <AnimatePresence initial={false}>
              {questions.map((q, i) => (
                <QuestionCard key={q.id} q={q} index={i} />
              ))}
            </AnimatePresence>

            {status === 'running' && (
              <motion.div
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                className="rounded-lg border border-dashed border-agent/40 bg-agent/[0.03] p-3 flex items-center gap-2 text-sm text-agent"
              >
                <Loader2 className="size-4 animate-spin" />
                generating…
              </motion.div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Live logs */}
      {(status === 'running' || stageLogs.length > 0) && (
        <div className="rounded-lg bg-background/40 border border-border p-3 font-mono text-[11px] space-y-1 max-h-40 overflow-y-auto">
          {stageLogs.length === 0 && status === 'running' && (
            <div className="text-muted-foreground/60">conditioning on Bloom's level…</div>
          )}
          <AnimatePresence initial={false}>
            {stageLogs.map((l, i) => (
              <motion.div
                key={`${l.ts}-${i}`}
                initial={{ opacity: 0, x: -4 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex gap-2"
              >
                <span className="text-muted-foreground/60">
                  {new Date(l.ts).toLocaleTimeString([], { hour12: false })}
                </span>
                <span
                  className={
                    l.level === 'error'
                      ? 'text-red-400'
                      : l.level === 'warn'
                        ? 'text-amber-400'
                        : l.level === 'thought'
                          ? 'text-agent/80'
                          : 'text-foreground/80'
                  }
                >
                  {l.text}
                </span>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  )
}

function QuestionCard({ q, index }: { q: GeneratedQuestion; index: number }) {
  const meta = getBloomMeta(q.bloom)
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 12, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ type: 'spring', stiffness: 260, damping: 24 }}
      className="rounded-xl border border-border bg-surface/40 p-4"
    >
      <div className="flex items-start gap-3">
        <span className="size-6 shrink-0 inline-flex items-center justify-center rounded-md bg-foreground/5 font-mono text-[10px] text-muted-foreground">
          {String(index + 1).padStart(2, '0')}
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2 mb-2 flex-wrap">
            <span
              className="text-[10px] font-mono px-1.5 py-0.5 rounded"
              style={{ background: `${meta.color}22`, color: meta.color }}
            >
              {meta.label}
            </span>
            <span className="text-[10px] font-mono text-muted-foreground">
              skill: {q.skill}
            </span>
            <span className="text-[10px] font-mono text-muted-foreground/60 ml-auto">
              {q.id}
            </span>
          </div>
          <p className="text-sm leading-relaxed">{q.question}</p>
          <p className="mt-2 text-xs text-muted-foreground italic">
            {q.rationale}
          </p>
        </div>
      </div>
    </motion.div>
  )
}
