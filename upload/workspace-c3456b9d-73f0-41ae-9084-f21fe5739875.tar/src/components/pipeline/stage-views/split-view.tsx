'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { useMemo, useEffect, useState } from 'react'
import { MessageSquarePlus, Sparkles, Loader2, Brain } from 'lucide-react'
import { usePipelineStore } from '@/lib/store'
import { usePipelineStageStatus } from '@/components/pipeline/use-stage-status'
import { getBloomMeta } from '@/lib/bloom'
import { BloomSelector } from '@/components/bloom-selector'
import type { StageId } from '@/lib/types'

/**
 * Combined Question-Generation + Answering split view.
 *
 * Per the spec: "The screen splits horizontally. The top half shows the
 * Question Generation agent; the bottom half shows the Answering agent."
 *
 * Bloom's segmented control sits above the generator. Text streams in via
 * a word-by-word typewriter effect (opacity fade per word).
 */
export default function SplitView({ activeHalf }: { activeHalf: StageId }) {
  const pairs = usePipelineStore((s) => s.pairs)
  const bloom = usePipelineStore((s) => s.bloom)
  const qStatus = usePipelineStageStatus('question-generation')
  const aStatus = usePipelineStageStatus('answering')

  const topActive = activeHalf === 'question-generation'

  return (
    <div className="h-full flex flex-col">
      {/* Bloom's control strip — sits above the split, biases the generator live */}
      <div className="shrink-0 border-b border-border bg-surface/30 px-4 sm:px-8 py-3">
        <div className="max-w-5xl mx-auto flex items-center gap-4">
          <div className="flex items-center gap-2 text-xs text-muted-foreground shrink-0">
            <Brain className="size-3.5" />
            Bloom's
          </div>
          <div className="flex-1 min-w-0">
            <BloomSelector value={bloom} compact />
          </div>
        </div>
      </div>

      {/* Horizontal split */}
      <div className="flex-1 grid grid-rows-2 min-h-0">
        {/* Top half — Question Generation */}
        <SplitPane
          active={topActive}
          accent="#5ee0c6"
          icon={MessageSquarePlus}
          agentLabel="Question Agent"
          status={qStatus}
          title="Question Generation"
        >
          <QuestionList pairs={pairs} running={qStatus === 'running'} />
        </SplitPane>

        {/* Divider */}
        <div className="h-px bg-border shrink-0 relative">
          <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-agent/40 to-transparent" />
        </div>

        {/* Bottom half — Answering */}
        <SplitPane
          active={!topActive}
          accent="#7dd3a0"
          icon={Sparkles}
          agentLabel="Answer Agent"
          status={aStatus}
          title="Answering"
        >
          <AnswerList pairs={pairs} running={aStatus === 'running'} />
        </SplitPane>
      </div>
    </div>
  )
}

function SplitPane({
  active,
  accent,
  icon: Icon,
  agentLabel,
  status,
  title,
  children,
}: {
  active: boolean
  accent: string
  icon: typeof MessageSquarePlus
  agentLabel: string
  status: string
  title: string
  children: React.ReactNode
}) {
  return (
    <div
      className="relative min-h-0 overflow-hidden transition-colors"
      style={{
        background: active ? `linear-gradient(180deg, ${accent}0a, transparent 60%)` : undefined,
      }}
    >
      {/* Active glow border */}
      {active && (
        <motion.div
          layoutId={`pane-glow-${title}`}
          className="absolute inset-0 pointer-events-none"
          style={{ boxShadow: `inset 0 0 0 1px ${accent}40, inset 0 0 40px -10px ${accent}30` }}
        />
      )}
      {/* Header */}
      <div className="shrink-0 px-4 sm:px-8 py-3 flex items-center gap-2 border-b border-border/60">
        <Icon className="size-3.5" style={{ color: accent }} />
        <span className="text-xs text-muted-foreground">{agentLabel}</span>
        <span className="text-sm font-medium">{title}</span>
        {status === 'running' && (
          <span className="ml-auto flex items-center gap-1.5 text-xs" style={{ color: accent }}>
            <Loader2 className="size-3 animate-spin" />
            working
          </span>
        )}
        {status === 'done' && (
          <span className="ml-auto text-xs text-emerald-400">complete</span>
        )}
      </div>
      {/* Content */}
      <div className="h-[calc(100%-3rem)] overflow-y-auto">
        <div className="max-w-3xl mx-auto px-4 sm:px-8 py-4">{children}</div>
      </div>
    </div>
  )
}

// ── Question list with typewriter streaming ──────────────────────────────
function QuestionList({
  pairs,
  running,
}: {
  pairs: import('@/lib/types').QAPair[]
  running: boolean
}) {
  const questions = pairs.map((p) => p.question)
  if (questions.length === 0 && !running) {
    return (
      <div className="text-center py-8 text-sm text-muted-foreground">
        Questions will stream in here as the Question agent generates them.
      </div>
    )
  }
  return (
    <div className="space-y-3">
      <AnimatePresence initial={false}>
        {questions.map((q, i) => (
          <QuestionCard key={q.id} q={q} index={i} isNew={running} />
        ))}
      </AnimatePresence>
      {running && (
        <motion.div
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-lg border border-dashed border-agent/40 bg-agent/[0.03] p-3 flex items-center gap-2 text-sm text-agent"
        >
          <Loader2 className="size-4 animate-spin" />
          generating…
        </motion.div>
      )}
    </div>
  )
}

function QuestionCard({
  q,
  index,
  isNew,
}: {
  q: import('@/lib/types').GeneratedQuestion
  index: number
  isNew: boolean
}) {
  const meta = getBloomMeta(q.bloom)
  const words = useMemo(() => q.question.split(/\s+/), [q.question])
  // Typewriter: start at 0 words revealed, increment via interval.
  // For non-new (already-complete) questions, jump straight to full.
  const [revealed, setRevealed] = useState(isNew ? 0 : words.length)

  useEffect(() => {
    if (!isNew) {
      // Already fully revealed — nothing to animate.
      return
    }
    let i = 0
    const interval = setInterval(() => {
      i += 1
      setRevealed(i)
      if (i >= words.length) clearInterval(interval)
    }, 45)
    return () => clearInterval(interval)
  }, [isNew, words.length])

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 12, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ type: 'spring', stiffness: 260, damping: 24 }}
      className="rounded-xl border border-border bg-surface/40 p-4"
    >
      <div className="flex items-start gap-3">
        <span className="size-6 shrink-0 inline-flex items-center justify-center rounded-md bg-foreground/5 font-mono text-[10px] text-muted-foreground">
          {String(index + 1).padStart(2, '0')}
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2 mb-2 flex-wrap">
            <span
              className="text-[10px] font-mono px-1.5 py-0.5 rounded"
              style={{ background: `${meta.color}22`, color: meta.color }}
            >
              {meta.label}
            </span>
            <span className="text-[10px] font-mono text-muted-foreground">
              skill: {q.skill}
            </span>
            <span className="text-[10px] font-mono text-muted-foreground/60 ml-auto">
              {q.id}
            </span>
          </div>
          <p className="text-sm leading-relaxed">
            {words.map((w, i) => (
              <span
                key={i}
                style={{
                  opacity: i < revealed ? 1 : 0,
                  transition: 'opacity 0.1s',
                  display: 'inline-block',
                  marginRight: '0.25em',
                }}
              >
                {w}
              </span>
            ))}
            {revealed < words.length && (
              <span className="inline-block w-1.5 h-3.5 bg-agent align-middle ml-0.5 animate-pulse" />
            )}
          </p>
          {revealed >= words.length && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="mt-2 text-xs text-muted-foreground italic"
            >
              {q.rationale}
            </motion.p>
          )}
        </div>
      </div>
    </motion.div>
  )
}

// ── Answer list with typewriter streaming ────────────────────────────────
function AnswerList({
  pairs,
  running,
}: {
  pairs: import('@/lib/types').QAPair[]
  running: boolean
}) {
  const answered = pairs.filter((p) => p.answer !== null)
  if (answered.length === 0 && !running) {
    return (
      <div className="text-center py-8 text-sm text-muted-foreground">
        Independent answers will stream in here as the Answer agent derives them.
      </div>
    )
  }
  return (
    <div className="space-y-3">
      <AnimatePresence initial={false}>
        {pairs.map((p) => (
          <AnswerCard key={p.id} pair={p} />
        ))}
      </AnimatePresence>
      {running && (
        <motion.div
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-lg border border-dashed border-agent/40 bg-agent/[0.03] p-3 flex items-center gap-2 text-sm text-agent"
        >
          <Loader2 className="size-4 animate-spin" />
          answering…
        </motion.div>
      )}
    </div>
  )
}

function AnswerCard({
  pair,
}: {
  pair: import('@/lib/types').QAPair
}) {
  const meta = getBloomMeta(pair.question.bloom)
  const answerText = pair.answer?.answer ?? ''
  const words = useMemo(() => answerText.split(/\s+/), [answerText])
  // Typewriter: start at 0, increment via interval when answer arrives.
  const [revealed, setRevealed] = useState(0)

  useEffect(() => {
    if (!pair.answer) {
      return
    }
    let i = 0
    const interval = setInterval(() => {
      i += 1
      setRevealed(i)
      if (i >= words.length) clearInterval(interval)
    }, 30)
    return () => clearInterval(interval)
    // Re-run when the answer text changes (e.g. regeneration)
  }, [pair.answer?.answer, words.length])

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 12, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ type: 'spring', stiffness: 260, damping: 24 }}
      className="rounded-xl border border-border bg-surface/40 p-4"
    >
      {/* Collapsed question for context */}
      <div className="flex items-start gap-3 mb-3">
        <span
          className="text-[10px] font-mono px-1.5 py-0.5 rounded shrink-0"
          style={{ background: `${meta.color}22`, color: meta.color }}
        >
          {meta.label}
        </span>
        <p className="text-xs leading-relaxed text-foreground/70 line-clamp-2">
          {pair.question.question}
        </p>
      </div>

      <AnimatePresence mode="wait">
        {pair.answer ? (
          <motion.div
            key="answer"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="ml-1 border-l-2 border-agent/40 pl-3 space-y-2"
          >
            <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider text-agent">
              <Sparkles className="size-3" />
              Independent answer
            </div>
            <p className="text-sm leading-relaxed">
              {words.map((w, i) => (
                <span
                  key={i}
                  style={{
                    opacity: i < revealed ? 1 : 0,
                    transition: 'opacity 0.1s',
                    display: 'inline-block',
                    marginRight: '0.25em',
                  }}
                >
                  {w}
                </span>
              ))}
              {revealed < words.length && revealed > 0 && (
                <span className="inline-block w-1.5 h-3.5 bg-agent align-middle ml-0.5 animate-pulse" />
              )}
            </p>
            {revealed >= words.length && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.2 }}
                className="flex items-center gap-4 text-[11px] text-muted-foreground pt-1"
              >
                <ConfidenceMeter value={pair.answer.confidence} />
                <span>
                  cited:{' '}
                  <span className="font-mono">
                    {pair.answer.cited.length ? pair.answer.cited.join(', ') : '—'}
                  </span>
                </span>
                {pair.answer.assumptions.length > 0 && (
                  <span className="text-amber-400">
                    {pair.answer.assumptions.length} assumption
                    {pair.answer.assumptions.length > 1 ? 's' : ''}
                  </span>
                )}
              </motion.div>
            )}
          </motion.div>
        ) : (
          <motion.div
            key="pending"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="ml-1 flex items-center gap-2 text-xs text-muted-foreground"
          >
            <Loader2 className="size-3 animate-spin" />
            answering from diagram…
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  )
}

function ConfidenceMeter({ value }: { value: number }) {
  const pct = Math.round(value * 100)
  const color = value >= 0.7 ? '#7dd3a0' : value >= 0.4 ? '#facc15' : '#f87171'
  return (
    <div className="flex items-center gap-1.5">
      <span>confidence:</span>
      <div className="w-16 h-1.5 rounded-full bg-foreground/10 overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 0.5 }}
          className="h-full rounded-full"
          style={{ background: color }}
        />
      </div>
      <span className="font-mono" style={{ color }}>
        {pct}%
      </span>
    </div>
  )
}
