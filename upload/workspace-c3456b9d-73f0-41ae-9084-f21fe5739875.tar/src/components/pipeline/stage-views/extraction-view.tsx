'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { useMemo, useState, useEffect } from 'react'
import { ScanEye, Loader2, Boxes, GitBranch, FileText, PanelRightOpen } from 'lucide-react'
import { usePipelineStore } from '@/lib/store'
import { usePipelineStageStatus } from '@/components/pipeline/use-stage-status'
import { Button } from '@/components/ui/button'

export default function ExtractionView() {
  const extraction = usePipelineStore((s) => s.extraction)
  const diagram = usePipelineStore((s) => s.diagram)
  const logs = usePipelineStore((s) => s.logs)
  const stageStatus = usePipelineStageStatus('extraction')
  const setRightPanelOpen = usePipelineStore((s) => s.setRightPanelOpen)

  const stageLogs = useMemo(
    () => logs.filter((l) => l.stage === 'extraction').slice(-8),
    [logs],
  )

  const isScanning = stageStatus === 'running'

  return (
    <div className="h-full flex flex-col">
      <div className="flex-1 overflow-y-auto">
        <div className="mx-auto max-w-5xl px-4 sm:px-8 py-8 space-y-6">
          <header className="flex items-start justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <ScanEye className="size-3.5" />
                Vision Agent
              </div>
              <h2 className="text-2xl font-semibold tracking-tight">Extraction</h2>
              <p className="text-sm text-muted-foreground max-w-xl">
                The Vision agent parses your diagram into a structured representation:
                entities, relationships, labels, and rough spatial layout.
              </p>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setRightPanelOpen(true)}
              className="shrink-0"
            >
              <PanelRightOpen className="mr-1.5 size-3.5" />
              Context
            </Button>
          </header>

          <AnimatePresence mode="wait">
            {extraction ? (
              <motion.div
                key="extraction"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                className="space-y-6"
              >
                {/* Diagram + scan overlay (left side) */}
                {diagram && (
                  <div className="rounded-xl border border-border bg-surface/40 overflow-hidden">
                    <div className="px-3 py-2 border-b border-border text-xs text-muted-foreground flex items-center gap-2">
                      <FileText className="size-3.5" />
                      Source diagram
                      {isScanning && (
                        <span className="ml-auto flex items-center gap-1.5 text-agent">
                          <span className="size-1.5 rounded-full bg-agent animate-pulse" />
                          scanning
                        </span>
                      )}
                    </div>
                    <div className="relative max-h-[28rem] overflow-hidden bg-background">
                      {diagram.mimeType === 'application/pdf' ? (
                        <div className="aspect-[4/3] flex items-center justify-center text-muted-foreground">
                          PDF diagram preview unavailable
                        </div>
                      ) : (
                        <img
                          src={diagram.dataUrl}
                          alt={diagram.name}
                          className="w-full object-contain"
                        />
                      )}
                      {/* Scanning line — sweeps top to bottom continuously while running */}
                      {isScanning && <ScanLine />}
                    </div>
                  </div>
                )}

                {/* Summary card */}
                <div className="rounded-xl border border-border bg-surface/40 p-4">
                  <div className="flex items-start gap-3">
                    <div className="size-9 rounded-md bg-agent/10 flex items-center justify-center shrink-0">
                      <FileText className="size-4 text-agent" />
                    </div>
                    <div className="min-w-0">
                      <div className="text-xs uppercase tracking-wider text-muted-foreground">
                        Diagram type
                      </div>
                      <div className="text-sm font-medium">{extraction.diagramType}</div>
                      <p className="mt-1 text-sm text-muted-foreground">{extraction.summary}</p>
                    </div>
                  </div>
                </div>

                {/* Counts */}
                <div className="grid grid-cols-2 gap-3">
                  <StatCard icon={Boxes} label="Entities" value={extraction.entities.length} />
                  <StatCard
                    icon={GitBranch}
                    label="Relationships"
                    value={extraction.relationships.length}
                  />
                </div>

                {/* Graph visualization */}
                <GraphCanvas />

                {/* Entities list */}
                <div>
                  <div className="text-xs uppercase tracking-wider text-muted-foreground mb-2">
                    Entities
                  </div>
                  <div className="grid sm:grid-cols-2 gap-2">
                    {extraction.entities.map((e, i) => (
                      <motion.div
                        key={e.id}
                        initial={{ opacity: 0, x: -8 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.04 }}
                        className="flex items-center gap-3 rounded-lg border border-border bg-surface/40 p-2.5"
                      >
                        <span className="font-mono text-[10px] text-muted-foreground shrink-0 size-6 inline-flex items-center justify-center rounded bg-foreground/5">
                          {e.id}
                        </span>
                        <div className="min-w-0">
                          <div className="text-sm font-medium truncate">{e.label}</div>
                          <div className="text-[11px] text-muted-foreground">{e.type}</div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>

                {/* Relationships list */}
                <div>
                  <div className="text-xs uppercase tracking-wider text-muted-foreground mb-2">
                    Relationships
                  </div>
                  <div className="space-y-1.5">
                    {extraction.relationships.map((r, i) => {
                      const from = extraction.entities.find((e) => e.id === r.from)
                      const to = extraction.entities.find((e) => e.id === r.to)
                      return (
                        <motion.div
                          key={r.id}
                          initial={{ opacity: 0, x: -8 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: i * 0.04 }}
                          className="flex items-center gap-2 rounded-lg border border-border bg-surface/40 p-2.5 text-sm"
                        >
                          <span className="font-medium truncate">{from?.label ?? r.from}</span>
                          <span className="text-xs text-muted-foreground px-1.5 py-0.5 rounded bg-foreground/5">
                            {r.label}
                          </span>
                          <span className="text-muted-foreground">→</span>
                          <span className="font-medium truncate">{to?.label ?? r.to}</span>
                          <span className="ml-auto text-[10px] uppercase tracking-wider text-muted-foreground/60">
                            {r.kind}
                          </span>
                        </motion.div>
                      )
                    })}
                  </div>
                </div>
              </motion.div>
            ) : (
              <PendingState status={stageStatus} logs={stageLogs} />
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  )
}

/** The scanning line: a 1px horizontal line with a vertical gradient trail that
 *  sweeps top-to-bottom over the image continuously. */
function ScanLine() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      <motion.div
        initial={{ y: '-10%' }}
        animate={{ y: '110%' }}
        transition={{ duration: 2.2, repeat: Infinity, ease: 'linear' }}
        className="absolute inset-x-0 h-px bg-agent"
        style={{
          boxShadow: '0 0 8px 1px var(--agent), 0 0 24px 4px var(--agent-glow)',
        }}
      >
        {/* Gradient trail above the line */}
        <div
          className="absolute inset-x-0 bottom-0 h-16"
          style={{
            background:
              'linear-gradient(to top, var(--agent-glow), transparent)',
          }}
        />
      </motion.div>
      {/* Subtle grid overlay to suggest "parsing" */}
      <div
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage:
            'linear-gradient(to right, var(--agent)22 1px, transparent 1px), linear-gradient(to bottom, var(--agent)22 1px, transparent 1px)',
          backgroundSize: '24px 24px',
        }}
      />
    </div>
  )
}

function StatCard({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof Boxes
  label: string
  value: number
}) {
  return (
    <div className="rounded-xl border border-border bg-surface/40 p-4 flex items-center gap-3">
      <div className="size-9 rounded-md bg-foreground/5 flex items-center justify-center">
        <Icon className="size-4 text-muted-foreground" />
      </div>
      <div>
        <div className="text-2xl font-semibold tabular-nums">{value}</div>
        <div className="text-xs text-muted-foreground">{label}</div>
      </div>
    </div>
  )
}

function GraphCanvas() {
  const extraction = usePipelineStore((s) => s.extraction)

  const positioned = useMemo(() => {
    if (!extraction) return []
    const ents = extraction.entities
    return ents.map((e, i) => {
      if (e.position) {
        return { ...e, x: 40 + e.position.x * 520, y: 30 + e.position.y * 280 }
      }
      const angle = (i / ents.length) * Math.PI * 2
      return {
        ...e,
        x: 300 + Math.cos(angle) * 180,
        y: 170 + Math.sin(angle) * 110,
      }
    })
  }, [extraction])

  if (!extraction) return null

  return (
    <div className="rounded-xl border border-border bg-surface/40 overflow-hidden">
      <div className="px-3 py-2 border-b border-border text-xs text-muted-foreground flex items-center gap-2">
        <Boxes className="size-3.5" />
        Structure graph
      </div>
      <svg viewBox="0 0 600 320" className="w-full h-auto">
        <defs>
          <marker id="arrow" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">
            <path d="M0,0 L6,3 L0,6 z" fill="#5ee0c6" />
          </marker>
        </defs>
        {extraction.relationships.map((r) => {
          const from = positioned.find((p) => p.id === r.from)
          const to = positioned.find((p) => p.id === r.to)
          if (!from || !to) return null
          const mx = (from.x + to.x) / 2
          const my = (from.y + to.y) / 2
          return (
            <motion.g
              key={r.id}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
            >
              <motion.path
                d={`M ${from.x} ${from.y} Q ${mx} ${my - 12} ${to.x} ${to.y}`}
                fill="none"
                stroke="#5ee0c6"
                strokeWidth="1.2"
                strokeOpacity="0.5"
                markerEnd="url(#arrow)"
                initial={{ pathLength: 0 }}
                animate={{ pathLength: 1 }}
                transition={{ duration: 0.6, delay: 0.3 }}
              />
              <text
                x={mx}
                y={my - 4}
                textAnchor="middle"
                className="fill-muted-foreground"
                style={{ fontSize: '9px' }}
              >
                {r.label.length > 18 ? r.label.slice(0, 16) + '…' : r.label}
              </text>
            </motion.g>
          )
        })}
        {positioned.map((p, i) => (
          <motion.g
            key={p.id}
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.05 * i }}
            style={{ transformOrigin: `${p.x}px ${p.y}px` }}
          >
            <circle cx={p.x} cy={p.y} r="14" fill="#0e1116" stroke="#5ee0c6" strokeWidth="1.5" />
            <text
              x={p.x}
              y={p.y + 4}
              textAnchor="middle"
              style={{ fontSize: '9px' }}
              className="fill-foreground font-mono"
            >
              {p.id}
            </text>
            <text
              x={p.x}
              y={p.y + 28}
              textAnchor="middle"
              style={{ fontSize: '10px' }}
              className="fill-foreground"
            >
              {p.label.length > 16 ? p.label.slice(0, 14) + '…' : p.label}
            </text>
          </motion.g>
        ))}
      </svg>
    </div>
  )
}

function PendingState({
  status,
  logs,
}: {
  status: 'idle' | 'running' | 'done' | 'flagged' | 'rejected'
  logs: { ts: number; text: string; level: string }[]
}) {
  if (status === 'idle') {
    return (
      <div className="rounded-xl border border-dashed border-border bg-surface/30 p-12 text-center">
        <ScanEye className="size-8 mx-auto text-muted-foreground/40" />
        <div className="mt-3 text-sm text-muted-foreground">
          Waiting for a diagram. The Vision agent will start automatically once you run the pipeline.
        </div>
      </div>
    )
  }
  return (
    <div className="rounded-xl border border-border bg-surface/40 p-6 space-y-4">
      <div className="flex items-center gap-3">
        {status === 'running' && <Loader2 className="size-5 animate-spin text-agent" />}
        <div>
          <div className="text-sm font-medium">
            {status === 'running' ? 'Vision agent is parsing your diagram…' : 'Stage complete'}
          </div>
          <div className="text-xs text-muted-foreground">
            Parsing entities, relationships, labels, and spatial layout.
          </div>
        </div>
      </div>
      <div className="rounded-lg bg-background/40 border border-border p-3 font-mono text-[11px] space-y-1 max-h-48 overflow-y-auto">
        <AnimatePresence initial={false}>
          {logs.map((l, i) => (
            <motion.div
              key={`${l.ts}-${i}`}
              initial={{ opacity: 0, x: -4 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex gap-2"
            >
              <span className="text-muted-foreground/60">
                {new Date(l.ts).toLocaleTimeString([], { hour12: false })}
              </span>
              <span
                className={
                  l.level === 'error'
                    ? 'text-red-400'
                    : l.level === 'warn'
                      ? 'text-amber-400'
                      : l.level === 'thought'
                        ? 'text-agent/80'
                        : 'text-foreground/80'
                }
              >
                {l.text}
              </span>
            </motion.div>
          ))}
        </AnimatePresence>
        {logs.length === 0 && (
          <div className="text-muted-foreground/60">waiting for agent output…</div>
        )}
      </div>
    </div>
  )
}
