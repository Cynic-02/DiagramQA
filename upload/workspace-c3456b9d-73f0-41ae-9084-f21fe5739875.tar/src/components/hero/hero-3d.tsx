'use client'

import { Canvas, useFrame } from '@react-three/fiber'
import { Line, Points, PointMaterial } from '@react-three/drei'
import { useMemo, useRef, useState, useEffect, Suspense } from 'react'
import * as THREE from 'three'
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion'

/**
 * Blueprint Extrusion Hero.
 *
 * Concept: the camera starts top-down looking at a flat 2D architectural
 * wireframe drawn in faint glowing lines. As the page loads:
 *   1. The camera smoothly tilts from top-down → 45° isometric.
 *   2. The 2D lines "extrude" upward along the Z-axis into 3D walls.
 *   3. Nodes light up at intersections.
 *   4. Data packets (tiny glowing dots) travel along the connecting paths.
 *
 * On scroll, the canvas fades to 0 and the render loop pauses to save battery.
 */

// ── Architecture footprint ────────────────────────────────────────────────
// A simple microservice-style layout: 5 rooms + connecting corridors.
// All coordinates in XZ plane (Y is up, the extrusion axis).

interface FootprintNode {
  id: string
  pos: [number, number] // XZ
  size: [number, number] // XZ footprint
  height: number // extrusion height
  kind: 'input' | 'process' | 'output' | 'data'
}

const NODES: FootprintNode[] = [
  { id: 'client', pos: [-4.2, -1.8], size: [1.4, 1.4], height: 1.2, kind: 'input' },
  { id: 'gateway', pos: [-1.8, -1.8], size: [1.6, 1.4], height: 2.4, kind: 'process' },
  { id: 'auth', pos: [0.4, -2.6], size: [1.2, 1.2], height: 1.8, kind: 'process' },
  { id: 'orders', pos: [0.4, 0.2], size: [1.6, 1.4], height: 2.8, kind: 'process' },
  { id: 'payments', pos: [0.4, 2.4], size: [1.4, 1.2], height: 2.2, kind: 'process' },
  { id: 'db', pos: [2.6, -1.0], size: [1.2, 1.6], height: 3.4, kind: 'data' },
  { id: 'cache', pos: [2.6, 1.6], size: [1.0, 1.0], height: 1.6, kind: 'data' },
]

// Corridors as pairs of node ids (the path data packets travel).
const CORRIDORS: [string, string][] = [
  ['client', 'gateway'],
  ['gateway', 'auth'],
  ['gateway', 'orders'],
  ['orders', 'payments'],
  ['orders', 'db'],
  ['orders', 'cache'],
  ['gateway', 'cache'],
]

const KIND_COLOR: Record<FootprintNode['kind'], string> = {
  input: '#7dd3a0',
  process: '#5ee0c6',
  output: '#9bd9a1',
  data: '#a3e6d6',
}

// ── Camera rig: top-down → isometric tilt ─────────────────────────────────
function CameraRig({ scrollProgress }: { scrollProgress: number }) {
  const startTime = useRef<number | null>(null)

  useEffect(() => {
    // Set initial position via a one-shot side effect on the DOM camera.
    // The actual per-frame updates happen in useFrame via state.camera.
  }, [])

  useFrame((state) => {
    const cam = state.camera
    if (startTime.current === null) {
      // Start position: directly above, looking straight down.
      cam.position.set(0, 14, 0.01)
      cam.up.set(0, 1, 0)
      cam.lookAt(0, 0, 0)
      startTime.current = state.clock.elapsedTime
    }
    const t = Math.min(1, (state.clock.elapsedTime - startTime.current) / 2.2)

    // Ease: cubic out
    const ease = 1 - Math.pow(1 - t, 3)

    // Lerp from top-down [0, 14, 0.01] to isometric [8, 9, 8]
    const startX = 0, startY = 14, startZ = 0.01
    const endX = 8, endY = 9, endZ = 8
    const newX = startX + (endX - startX) * ease
    const newY = startY + (endY - startY) * ease
    const newZ = startZ + (endZ - startZ) * ease

    // Slight parallax with pointer after tilt completes
    let px = 0, pz = 0
    if (t >= 1) {
      px = state.pointer.x * 0.6
      pz = state.pointer.y * 0.4
    }
    cam.position.set(
      newX + (t >= 1 ? (endX + px - newX) * 0.02 : 0),
      newY,
      newZ + (t >= 1 ? (endZ + pz - newZ) * 0.02 : 0),
    )
    cam.lookAt(0, 0.5, 0)
  })

  // Pause render loop when scrolled past 60% (handled by parent frameloop prop).
  return null
}

// ── Extruded building ─────────────────────────────────────────────────────
function Building({ node, delay }: { node: FootprintNode; delay: number }) {
  const mesh = useRef<THREE.Mesh>(null!)
  const edges = useRef<THREE.LineSegments>(null!)
  const [extruded, setExtruded] = useState(false)
  const color = KIND_COLOR[node.kind]
  const heightRef = useRef(0)

  useEffect(() => {
    const t = setTimeout(() => setExtruded(true), delay * 1000)
    return () => clearTimeout(t)
  }, [delay])

  useFrame((_, delta) => {
    if (!mesh.current) return
    // Lerp the height from 0 to node.height
    const targetH = extruded ? node.height : 0.02
    heightRef.current += (targetH - heightRef.current) * Math.min(1, delta * 2.2)
    mesh.current.scale.y = heightRef.current
    mesh.current.position.y = heightRef.current / 2

    // Pulse the edges when fully extruded
    if (edges.current && extruded) {
      const m = edges.current.material as THREE.LineBasicMaterial
      m.opacity = 0.7 + Math.sin(performance.now() / 600 + delay * 10) * 0.15
    }
  })

  const [w, d] = node.size
  return (
    <group position={[node.pos[0], 0, node.pos[1]]}>
      {/* Faint floor footprint (always visible, even before extrusion) */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.01, 0]}>
        <planeGeometry args={[w, d]} />
        <meshBasicMaterial color={color} transparent opacity={0.06} />
      </mesh>
      {/* Floor outline */}
      <Line
        points={[
          [-w / 2, 0.02, -d / 2],
          [w / 2, 0.02, -d / 2],
          [w / 2, 0.02, d / 2],
          [-w / 2, 0.02, d / 2],
          [-w / 2, 0.02, -d / 2],
        ]}
        color={color}
        lineWidth={1}
        transparent
        opacity={0.4}
      />
      {/* Extruded building (walls) */}
      <mesh ref={mesh} position={[0, 0.01, 0]}>
        <boxGeometry args={[w, 1, d]} />
        <meshStandardMaterial
          color={color}
          emissive={color}
          emissiveIntensity={0.25}
          transparent
          opacity={0.12}
          roughness={0.5}
          metalness={0.1}
        />
      </mesh>
      {/* Edge wireframe of the building */}
      <lineSegments ref={edges}>
        <edgesGeometry args={[new THREE.BoxGeometry(w, node.height, d)]} />
        <lineBasicMaterial color={color} transparent opacity={0.7} />
      </lineSegments>
      {/* Roof node — a glowing icosahedron at full height */}
      <mesh position={[0, node.height + 0.2, 0]}>
        <icosahedronGeometry args={[0.12, 1]} />
        <meshStandardMaterial
          color={color}
          emissive={color}
          emissiveIntensity={1.2}
          toneMapped={false}
        />
      </mesh>
      {/* Vertical light beam from roof to sky */}
      <mesh position={[0, node.height + 1.5, 0]}>
        <cylinderGeometry args={[0.015, 0.015, 3, 6]} />
        <meshBasicMaterial color={color} transparent opacity={0.3} />
      </mesh>
    </group>
  )
}

// ── Corridor path + data packets ──────────────────────────────────────────
function Corridor({ from, to, delay }: { from: FootprintNode; to: FootprintNode; delay: number }) {
  const [active, setActive] = useState(false)
  useEffect(() => {
    const t = setTimeout(() => setActive(true), (delay + 0.8) * 1000)
    return () => clearTimeout(t)
  }, [delay])

  // The path runs at ground level between the two nodes.
  const points = useMemo<[number, number, number][]>(() => {
    return [
      [from.pos[0], 0.04, from.pos[1]],
      [to.pos[0], 0.04, to.pos[1]],
    ]
  }, [from.pos, to.pos])

  return (
    <>
      <Line
        points={points}
        color="#5ee0c6"
        lineWidth={1}
        transparent
        opacity={active ? 0.35 : 0}
      />
      {active && <DataPacket from={points[0]} to={points[1]} speed={0.35 + Math.random() * 0.2} offset={Math.random()} />}
    </>
  )
}

function DataPacket({
  from,
  to,
  speed,
  offset,
}: {
  from: [number, number, number]
  to: [number, number, number]
  speed: number
  offset: number
}) {
  const mesh = useRef<THREE.Mesh>(null!)
  const tRef = useRef(offset)
  const fromV = useMemo(() => new THREE.Vector3(...from), [from])
  const toV = useMemo(() => new THREE.Vector3(...to), [to])

  useFrame((_, delta) => {
    if (!mesh.current) return
    tRef.current = (tRef.current + delta * speed) % 1
    mesh.current.position.lerpVectors(fromV, toV, tRef.current)
    // Bob slightly above the ground
    mesh.current.position.y = 0.15 + Math.sin(tRef.current * Math.PI) * 0.3
  })

  return (
    <mesh ref={mesh}>
      <sphereGeometry args={[0.06, 8, 8]} />
      <meshBasicMaterial color="#7dd3a0" toneMapped={false} />
    </mesh>
  )
}

// ── Ground grid (the "blueprint" base) ────────────────────────────────────
function GroundGrid() {
  const positions = useMemo(() => {
    const arr: number[] = []
    const N = 24
    const spacing = 0.5
    for (let x = -N / 2; x < N / 2; x++) {
      for (let z = -N / 2; z < N / 2; z++) {
        arr.push(x * spacing, 0, z * spacing)
      }
    }
    return new Float32Array(arr)
  }, [])
  return (
    <Points positions={positions} stride={3}>
      <PointMaterial transparent color="#5ee0c6" size={0.02} sizeAttenuation depthWrite={false} opacity={0.25} />
    </Points>
  )
}

// ── Scene ─────────────────────────────────────────────────────────────────
function Scene({ scrollProgress }: { scrollProgress: number }) {
  const nodeMap = useMemo(() => {
    const m = new Map<string, FootprintNode>()
    NODES.forEach((n) => m.set(n.id, n))
    return m
  }, [])

  return (
    <>
      <ambientLight intensity={0.4} />
      <pointLight position={[8, 12, 8]} intensity={1.0} color="#5ee0c6" />
      <pointLight position={[-6, 6, -4]} intensity={0.5} color="#7dd3a0" />
      <CameraRig scrollProgress={scrollProgress} />
      <GroundGrid />
      {NODES.map((n, i) => (
        <Building key={n.id} node={n} delay={0.6 + i * 0.18} />
      ))}
      {CORRIDORS.map(([a, b], i) => {
        const from = nodeMap.get(a)!
        const to = nodeMap.get(b)!
        return <Corridor key={i} from={from} to={to} delay={1.4 + i * 0.12} />
      })}
    </>
  )
}

// ── Exported component ────────────────────────────────────────────────────
export interface Hero3DProps {
  scrollProgress: number
}

export default function Hero3D({ scrollProgress }: Hero3DProps) {
  const sv = useMotionValue(0)
  const smooth = useSpring(sv, { stiffness: 120, damping: 30, mass: 0.4 })
  useEffect(() => {
    sv.set(scrollProgress)
  }, [scrollProgress, sv])
  const opacity = useTransform(smooth, [0, 0.5, 1], [1, 0.7, 0])
  const scale = useTransform(smooth, [0, 1], [1, 0.94])

  // Pause the render loop when the hero is scrolled out of view.
  const frameloop = scrollProgress > 0.7 ? 'never' : 'always'

  return (
    <motion.div style={{ opacity, scale }} className="absolute inset-0" aria-hidden>
      <Canvas
        camera={{ position: [0, 14, 0.01], fov: 35, near: 0.1, far: 100 }}
        dpr={[1, 1.8]}
        gl={{ antialias: true, alpha: true, powerPreference: 'high-performance' }}
        frameloop={frameloop as 'always' | 'never'}
      >
        <Suspense fallback={null}>
          <Scene scrollProgress={scrollProgress} />
        </Suspense>
      </Canvas>
    </motion.div>
  )
}
