'use client'

import dynamic from 'next/dynamic'
import { motion, useScroll, useTransform } from 'framer-motion'
import { useRef, useState } from 'react'
import HeroFallback from './hero-3d-fallback'
import { Button } from '@/components/ui/button'
import { ArrowDown, ScanEye, MessageSquarePlus, Sparkles, ShieldCheck } from 'lucide-react'

// Detect WebGL availability once at module load (client-only after dynamic import).
function detectWebgl(): boolean {
  if (typeof window === 'undefined') return true
  try {
    const c = document.createElement('canvas')
    const gl = c.getContext('webgl2') || c.getContext('webgl')
    return !!gl
  } catch {
    return false
  }
}

// Lazy-load the 3D canvas so it never blocks first paint, and so low-end
// devices can opt out via the static fallback if WebGL fails.
const Hero3D = dynamic(() => import('./hero-3d'), {
  ssr: false,
  loading: () => <HeroFallback />,
})

const AGENT_PILLS = [
  { icon: ScanEye, label: 'Vision' },
  { icon: MessageSquarePlus, label: 'Generate' },
  { icon: Sparkles, label: 'Answer' },
  { icon: ShieldCheck, label: 'Verify' },
]

export default function HeroSection({
  onEnter,
}: {
  onEnter: () => void
}) {
  const ref = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start start', 'end start'],
  })

  const heroY = useTransform(scrollYProgress, [0, 1], ['0%', '-40%'])
  const heroOpacity = useTransform(scrollYProgress, [0, 0.7, 1], [1, 0.6, 0])
  const scrollHintOpacity = useTransform(scrollYProgress, [0, 0.2], [1, 0])

  const [webglOk] = useState<boolean>(detectWebgl)

  return (
    <section ref={ref} className="relative h-[180vh]">
      {/* Sticky hero viewport */}
      <div className="sticky top-0 h-screen overflow-hidden">
        {/* Background layers */}
        <div className="absolute inset-0 bg-grid opacity-40" />
        <div className="absolute inset-0 bg-gradient-to-b from-background/0 via-background/40 to-background" />

        {/* 3D canvas / fallback */}
        {webglOk ? (
          <Hero3D scrollProgress={scrollYProgress} />
        ) : (
          <HeroFallback />
        )}

        {/* Foreground content */}
        <motion.div
          style={{ y: heroY, opacity: heroOpacity }}
          className="relative z-10 h-full flex flex-col items-center justify-center px-6"
        >
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="flex items-center gap-2 px-3 py-1 rounded-full glass text-xs text-muted-foreground"
          >
            <span className="size-1.5 rounded-full bg-agent animate-pulse" />
            AR2-DDCQG · Blueprint → Knowledge Graph
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.5 }}
            className="mt-6 text-center text-5xl sm:text-6xl md:text-7xl font-semibold tracking-tight max-w-4xl"
          >
            From <span className="text-gradient-agent">blueprint</span> to verified
            <br className="hidden sm:block" /> Q&A — autonomously.
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.6 }}
            className="mt-6 text-center text-muted-foreground max-w-xl text-base sm:text-lg"
          >
            Upload any diagram. A team of agents extracts the structure, generates
            Bloom&rsquo;s-conditioned questions, cross-checks the answers, and
            verifies every pair before you see it.
          </motion.p>

          {/* Agent pills */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.7 }}
            className="mt-10 flex flex-wrap items-center justify-center gap-2"
          >
            {AGENT_PILLS.map((p, i) => (
              <div key={p.label} className="flex items-center gap-2">
                <div className="flex items-center gap-2 px-3 py-1.5 rounded-full glass text-sm">
                  <p.icon className="size-3.5 text-agent" />
                  {p.label}
                </div>
                {i < AGENT_PILLS.length - 1 && (
                  <span className="text-muted-foreground/40 text-xs">→</span>
                )}
              </div>
            ))}
          </motion.div>

          {/* CTA */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.8 }}
            className="mt-10 flex items-center gap-3"
          >
            <Button
              size="lg"
              onClick={onEnter}
              className="bg-agent text-accent-foreground hover:bg-agent/90 px-6"
            >
              Enter the workspace
              <ArrowDown className="ml-2 size-4" />
            </Button>
          </motion.div>
        </motion.div>

        {/* Scroll hint */}
        <motion.div
          style={{ opacity: scrollHintOpacity }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 text-xs text-muted-foreground flex flex-col items-center gap-2"
        >
          <span>scroll to enter</span>
          <motion.div
            animate={{ y: [0, 6, 0] }}
            transition={{ duration: 1.6, repeat: Infinity, ease: 'easeInOut' }}
            className="size-1.5 rounded-full bg-agent"
          />
        </motion.div>
      </div>
    </section>
  )
}
