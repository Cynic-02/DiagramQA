'use client'

import { motion } from 'framer-motion'

/** Static SVG fallback for the hero — used on low-end devices or when WebGL is unavailable. */
export default function HeroFallback() {
  const nodes = [
    { x: 90, y: 110, c: '#7dd3a0' },
    { x: 90, y: 290, c: '#7dd3a0' },
    { x: 260, y: 200, c: '#5ee0c6' },
    { x: 430, y: 120, c: '#5ee0c6' },
    { x: 430, y: 280, c: '#5ee0c6' },
    { x: 600, y: 140, c: '#9bd9a1' },
    { x: 600, y: 260, c: '#9bd9a1' },
    { x: 345, y: 200, c: '#a3e6d6' },
  ]
  const edges: [number, number][] = [
    [0, 2], [1, 2], [2, 3], [2, 4], [3, 5], [4, 6], [3, 7], [4, 7],
  ]
  return (
    <div className="absolute inset-0 flex items-center justify-center" aria-hidden>
      <svg viewBox="0 0 700 400" className="w-full h-full max-w-3xl opacity-90">
        <defs>
          <radialGradient id="glow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#5ee0c6" stopOpacity="0.4" />
            <stop offset="100%" stopColor="#5ee0c6" stopOpacity="0" />
          </radialGradient>
        </defs>
        <rect x="0" y="0" width="700" height="400" fill="url(#glow)" opacity="0.3" />
        {edges.map(([a, b], i) => (
          <motion.line
            key={i}
            x1={nodes[a].x}
            y1={nodes[a].y}
            x2={nodes[b].x}
            y2={nodes[b].y}
            stroke="#5ee0c6"
            strokeWidth="1.2"
            strokeOpacity="0.5"
            initial={{ pathLength: 0, opacity: 0 }}
            animate={{ pathLength: 1, opacity: 0.5 }}
            transition={{ duration: 0.8, delay: 0.5 + i * 0.1 }}
          />
        ))}
        {nodes.map((n, i) => (
          <motion.circle
            key={i}
            cx={n.x}
            cy={n.y}
            r="8"
            fill={n.c}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 0.92 }}
            transition={{ duration: 0.5, delay: 0.2 + i * 0.12 }}
          />
        ))}
      </svg>
    </div>
  )
}
