'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { BLOOM_LEVELS, getBloomMeta } from '@/lib/bloom'
import { usePipelineStore } from '@/lib/store'
import type { BloomLevel } from '@/lib/types'
import { cn } from '@/lib/utils'

export function BloomSelector({
  value,
  compact = false,
}: {
  value: BloomLevel
  compact?: boolean
}) {
  const setBloom = usePipelineStore((s) => s.setBloom)
  const running = usePipelineStore((s) => s.running)
  const activeMeta = getBloomMeta(value)

  if (compact) {
    // Compact segmented control — single row of buttons, no description panel.
    return (
      <div className="space-y-2">
        <div className="flex items-center gap-1 rounded-lg bg-surface p-1 overflow-x-auto no-scrollbar">
          {BLOOM_LEVELS.map((b) => {
            const active = b.id === value
            return (
              <button
                key={b.id}
                disabled={running}
                onClick={() => setBloom(b.id)}
                className={cn(
                  'relative flex-1 min-w-fit h-7 px-2.5 rounded-md text-[11px] font-medium transition-colors whitespace-nowrap',
                  active ? 'text-accent-foreground' : 'text-muted-foreground hover:text-foreground',
                  running && 'cursor-not-allowed opacity-60',
                )}
                title={`${b.label} — ${b.description}`}
              >
                {active && (
                  <motion.div
                    layoutId="bloom-pill-compact"
                    className="absolute inset-0 rounded-md"
                    style={{ background: b.color }}
                    transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                  />
                )}
                <span className="relative z-10">{b.label}</span>
              </button>
            )
          })}
        </div>
        <div className="flex items-center gap-2 text-[11px]">
          <span
            className="size-1.5 rounded-full shrink-0"
            style={{ background: activeMeta.color }}
          />
          <span className="text-muted-foreground">{activeMeta.tagline}</span>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-3">
      {/* Slider rail — Remember (left) to Create (right) */}
      <div className="relative h-9 rounded-lg bg-surface px-1.5 flex items-center">
        {BLOOM_LEVELS.map((b) => {
          const active = b.id === value
          return (
            <button
              key={b.id}
              disabled={running}
              onClick={() => setBloom(b.id)}
              className={cn(
                'relative z-10 flex-1 h-7 rounded-md text-[11px] font-medium transition-colors',
                active ? 'text-accent-foreground' : 'text-muted-foreground hover:text-foreground',
                running && 'cursor-not-allowed opacity-60',
              )}
              style={active ? { background: b.color } : undefined}
              title={`${b.label} — ${b.description}`}
            >
              {b.label}
            </button>
          )
        })}
        <div className="absolute inset-x-1.5 bottom-1 h-px bg-gradient-to-r from-transparent via-foreground/10 to-transparent pointer-events-none" />
      </div>

      <div className="rounded-lg border border-border bg-surface/40 p-3">
        <div className="flex items-center gap-2">
          <span
            className="size-2 rounded-full"
            style={{ background: activeMeta.color }}
          />
          <span className="text-sm font-medium">{activeMeta.label}</span>
          <span className="text-xs text-muted-foreground">· {activeMeta.tagline}</span>
        </div>
        <p className="mt-2 text-xs text-muted-foreground leading-relaxed">
          {activeMeta.description}
        </p>
        <div className="mt-2 flex flex-wrap gap-1">
          {activeMeta.verbs.slice(0, 5).map((v) => (
            <span
              key={v}
              className="px-2 py-0.5 rounded-full bg-foreground/[0.05] text-[10px] font-mono text-muted-foreground"
            >
              {v}
            </span>
          ))}
        </div>
      </div>

      {/* Difficulty rank visualization */}
      <div className="flex items-center gap-1">
        {BLOOM_LEVELS.map((b) => (
          <div
            key={b.id}
            className={cn(
              'h-1 flex-1 rounded-full transition-all',
              b.rank <= activeMeta.rank ? 'bg-agent' : 'bg-foreground/10',
            )}
            style={b.rank <= activeMeta.rank ? { background: b.color } : undefined}
          />
        ))}
      </div>
      <div className="flex justify-between text-[10px] text-muted-foreground/70">
        <span>lower order</span>
        <span>higher order</span>
      </div>
    </div>
  )
}
