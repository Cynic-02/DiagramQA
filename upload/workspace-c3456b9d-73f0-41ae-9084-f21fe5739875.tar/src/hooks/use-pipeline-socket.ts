'use client'

import { useEffect } from 'react'
import { getSocket, onConnect, onDisconnect, onEvent, sendCommand } from '@/lib/socket'
import { usePipelineStore } from '@/lib/store'
import type { PipelineEvent } from '@/lib/types'

/**
 * Subscribes to the agent-pipeline mini-service and dispatches every event
 * into the Zustand store. Mounted once at the top of the page.
 */
export function usePipelineSocket() {
  const {
    setSocketConnected,
    setStage,
    setExtraction,
    upsertQuestion,
    upsertAnswer,
    upsertVerification,
    completeRun,
    setError,
    pushLog,
  } = usePipelineStore.getState()

  useEffect(() => {
    const socket = getSocket()

    const offConnect = onConnect(() => setSocketConnected(true))
    const offDisconnect = onDisconnect(() => setSocketConnected(false))

    const offEvent = onEvent((e: PipelineEvent) => {
      switch (e.type) {
        case 'stage:start':
          setStage(e.stage, 'running')
          pushLog({ stage: e.stage, level: 'info', text: 'stage started' })
          break
        case 'stage:progress':
          setStage(e.stage, 'running')
          pushLog({
            stage: e.stage,
            level: e.level ?? 'info',
            text: e.message,
          })
          break
        case 'stage:done':
          setStage(e.stage, 'done', e.note)
          pushLog({ stage: e.stage, level: 'info', text: `stage done — ${e.note ?? ''}` })
          break
        case 'stage:flagged':
          setStage(e.stage, 'flagged', e.note)
          pushLog({ stage: e.stage, level: 'warn', text: e.note })
          break
        case 'stage:rejected':
          setStage(e.stage, 'rejected', e.note)
          pushLog({ stage: e.stage, level: 'error', text: e.note })
          break
        case 'extraction':
          setExtraction(e.data)
          break
        case 'question': {
          const q = e.data
          upsertQuestion({
            id: q.id,
            question: q,
            answer: null,
            verification: null,
            attempts: 0,
          })
          pushLog({
            stage: 'question-generation',
            level: 'info',
            text: `generated [${q.bloom}] ${q.question.slice(0, 80)}…`,
          })
          break
        }
        case 'answer':
          upsertAnswer(e.data.questionId, e.data)
          pushLog({
            stage: 'answering',
            level: 'thought',
            text: `answered ${e.data.questionId} (conf=${e.data.confidence.toFixed(2)})`,
          })
          break
        case 'verification':
          upsertVerification(e.data.questionId, e.data)
          pushLog({
            stage: 'verification',
            level: e.data.verdict === 'pass' ? 'info' : e.data.verdict === 'flag' ? 'warn' : 'error',
            text: `${e.data.verdict.toUpperCase()} ${e.data.questionId} — ${e.data.notes.slice(0, 80)}`,
          })
          break
        case 'pair:regenerate':
          // handled by the next 'question' event that overwrites this id
          pushLog({
            stage: 'verification',
            level: 'warn',
            text: `regenerate ${e.data.questionId} — ${e.data.reason}`,
          })
          break
        case 'run:complete':
          completeRun(e.meta)
          break
        case 'run:error':
          setError(e.message)
          pushLog({
            stage: e.stage ?? 'extraction',
            level: 'error',
            text: e.message,
          })
          break
      }
    })

    // Make sure the socket is connected (idempotent)
    if (!socket.connected) socket.connect()

    return () => {
      offConnect()
      offDisconnect()
      offEvent()
    }
    // We deliberately don't include store functions — they're stable refs.
  }, [])
}

/** Convenience wrapper for kicking off a run from any component. */
export function useStartRun() {
  return (params: {
    diagram: { name: string; mimeType: string; dataUrl: string }
    bloom: import('@/lib/types').BloomLevel
    questionCount: number
  }) => {
    const { startRun } = usePipelineStore.getState()
    const runId = `run_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`
    startRun(runId)
    sendCommand({ type: 'run:start', ...params })
    return runId
  }
}

export function useCancelRun() {
  return () => sendCommand({ type: 'run:cancel' })
}
