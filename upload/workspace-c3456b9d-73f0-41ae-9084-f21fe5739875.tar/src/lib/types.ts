// Shared types for the AR2-DDCQG pipeline.
// Used by both the Next.js frontend and the socket.io mini-service contract.

export type StageId =
  | 'upload'
  | 'extraction'
  | 'question-generation'
  | 'answering'
  | 'verification'
  | 'results'

export type StageStatus = 'idle' | 'running' | 'done' | 'flagged' | 'rejected'

export interface StageState {
  id: StageId
  status: StageStatus
  /** Monotonic timestamp (ms) when the stage last changed status. */
  updatedAt: number
  /** Optional human-readable note (e.g. rejection reason). */
  note?: string
}

export type BloomLevel =
  | 'remember'
  | 'understand'
  | 'apply'
  | 'analyze'
  | 'evaluate'
  | 'create'

/** A node/entity extracted from the diagram by the Vision agent. */
export interface ExtractedEntity {
  id: string
  label: string
  type: string
  /** Optional spatial hint, normalized 0..1 in image space. */
  position?: { x: number; y: number }
}

/** A relationship/edge between two entities. */
export interface ExtractedRelationship {
  id: string
  from: string
  to: string
  label: string
  kind?: 'flow' | 'data' | 'control' | 'contains' | 'references'
}

export interface ExtractionResult {
  diagramType: string
  summary: string
  entities: ExtractedEntity[]
  relationships: ExtractedRelationship[]
  rawMarkdown: string
}

export interface GeneratedQuestion {
  id: string
  question: string
  bloom: BloomLevel
  /** Hint at the cognitive skill targeted (e.g. "trace", "compare", "design"). */
  skill: string
  /** Why this question was picked from the structure. */
  rationale: string
}

export interface AnswerResult {
  questionId: string
  answer: string
  /** Confidence 0..1 reported by the answering agent. */
  confidence: number
  /** Which entities/relationships were cited. */
  cited: string[]
  /** Did the answering agent have to make assumptions beyond the diagram? */
  assumptions: string[]
}

export type VerificationVerdict =
  | 'pass'
  | 'regenerate'
  | 'flag'

export interface VerificationResult {
  questionId: string
  verdict: VerificationVerdict
  correct: boolean
  ambiguity: number // 0..1
  difficultyMatch: number // 0..1
  notes: string
  /** True if the generator appears to leak the answer into the question. */
  leaksAnswer: boolean
}

export interface QAPair {
  id: string
  question: GeneratedQuestion
  answer: AnswerResult | null
  verification: VerificationResult | null
  /** How many times this pair has been regenerated. */
  attempts: number
}

export interface PipelineRunMeta {
  runId: string
  startedAt: number
  finishedAt?: number
  bloom: BloomLevel
  questionCount: number
}

/** Single log line emitted by an agent during a stage. */
export interface AgentLogLine {
  ts: number
  stage: StageId
  level: 'info' | 'warn' | 'error' | 'thought'
  text: string
}

/** Event payloads sent over the socket from the mini-service to the client. */
export type PipelineEvent =
  | { type: 'stage:start'; stage: StageId }
  | { type: 'stage:progress'; stage: StageId; message: string; level?: 'info' | 'warn' | 'error' | 'thought' }
  | { type: 'stage:done'; stage: StageId; note?: string }
  | { type: 'stage:flagged'; stage: StageId; note: string }
  | { type: 'stage:rejected'; stage: StageId; note: string }
  | { type: 'extraction'; data: ExtractionResult }
  | { type: 'question'; data: GeneratedQuestion }
  | { type: 'answer'; data: AnswerResult }
  | { type: 'verification'; data: VerificationResult }
  | { type: 'pair:regenerate'; questionId: string; reason: string }
  | { type: 'run:complete'; meta: PipelineRunMeta }
  | { type: 'run:error'; message: string; stage?: StageId }

/** Commands the client sends to the mini-service. */
export type PipelineCommand =
  | {
      type: 'run:start'
      diagram: { name: string; mimeType: string; dataUrl: string }
      bloom: BloomLevel
      questionCount: number
    }
  | { type: 'run:cancel' }
