'use client'

import { io, type Socket } from 'socket.io-client'
import type { PipelineCommand, PipelineEvent } from './types'

// Singleton socket client. Always uses the Caddy gateway path with
// XTransformPort=3003 — never a direct localhost URL.
let socket: Socket | null = null

export function getSocket(): Socket {
  if (socket) return socket

  socket = io('/?XTransformPort=3003', {
    transports: ['websocket', 'polling'],
    forceNew: true,
    reconnection: true,
    reconnectionAttempts: 10,
    reconnectionDelay: 1000,
    timeout: 15000,
  })

  return socket
}

export function sendCommand(cmd: PipelineCommand) {
  const s = getSocket()
  s.emit('command', cmd)
}

export function onEvent(handler: (e: PipelineEvent) => void) {
  const s = getSocket()
  s.on('pipeline:event', handler)
  return () => {
    s.off('pipeline:event', handler)
  }
}

export function onConnect(handler: () => void) {
  const s = getSocket()
  s.on('connect', handler)
  return () => s.off('connect', handler)
}

export function onDisconnect(handler: () => void) {
  const s = getSocket()
  s.on('disconnect', handler)
  return () => s.off('disconnect', handler)
}
