import type { BloomLevel, StageId, StageStatus } from './types'

export interface BloomMeta {
  id: BloomLevel
  label: string
  /** Short tagline shown in the UI. */
  tagline: string
  /** Verbs the generator should target. */
  verbs: string[]
  /** One-line description for tooltip/help. */
  description: string
  /** Difficulty rank 0..5 — used for the slider order. */
  rank: number
  /** Accent color (CSS color) used in chips and difficulty bar. */
  color: string
}

export const BLOOM_LEVELS: BloomMeta[] = [
  {
    id: 'remember',
    label: 'Remember',
    tagline: 'Recognize & recall',
    verbs: ['define', 'list', 'name', 'identify', 'label', 'recall'],
    description:
      'Direct recall of entities, labels, and relationships explicitly present in the diagram.',
    rank: 0,
    color: 'oklch(0.80 0.16 90)', // lime
  },
  {
    id: 'understand',
    label: 'Understand',
    tagline: 'Explain the structure',
    verbs: ['describe', 'summarize', 'explain', 'interpret', 'classify'],
    description:
      'Restate what the diagram represents in the student\'s own words — meaning, not just labels.',
    rank: 1,
    color: 'oklch(0.78 0.14 165)', // emerald
  },
  {
    id: 'apply',
    label: 'Apply',
    tagline: 'Trace the flow',
    verbs: ['trace', 'demonstrate', 'implement', 'execute', 'compute'],
    description:
      'Follow a path or process through the diagram to a concrete outcome.',
    rank: 2,
    color: 'oklch(0.74 0.14 200)', // teal-cyan
  },
  {
    id: 'analyze',
    label: 'Analyze',
    tagline: 'Compare & decompose',
    verbs: ['compare', 'contrast', 'decompose', 'differentiate', 'relate'],
    description:
      'Break the diagram into parts and reason about why entities relate the way they do.',
    rank: 3,
    color: 'oklch(0.72 0.18 40)', // amber
  },
  {
    id: 'evaluate',
    label: 'Evaluate',
    tagline: 'Judge & critique',
    verbs: ['justify', 'critique', 'assess', 'defend', 'prioritize'],
    description:
      'Make a judgment against criteria — e.g. which path is more efficient, which design is sounder.',
    rank: 4,
    color: 'oklch(0.70 0.20 16)', // red-orange
  },
  {
    id: 'create',
    label: 'Create',
    tagline: 'Design & extend',
    verbs: ['design', 'propose', 'extend', 'modify', 'generate'],
    description:
      'Compose a new variant — add a node, reroute a flow, propose an alternative architecture.',
    rank: 5,
    color: 'oklch(0.78 0.16 320)', // magenta
  },
]

export function getBloomMeta(id: BloomLevel): BloomMeta {
  return BLOOM_LEVELS.find((b) => b.id === id) ?? BLOOM_LEVELS[1]
}

export interface StageMeta {
  id: StageId
  label: string
  short: string
  /** The agent that owns this stage. */
  agent: string
  /** What this stage does, in one line. */
  description: string
  /** Icon name from lucide-react. */
  icon: string
}

export const PIPELINE_STAGES: StageMeta[] = [
  {
    id: 'upload',
    label: 'Source Diagram',
    short: 'Upload',
    agent: 'Ingest',
    description: 'Accept an image or PDF diagram and validate it for the pipeline.',
    icon: 'Upload',
  },
  {
    id: 'extraction',
    label: 'Extraction (Vision)',
    short: 'Extract',
    agent: 'Vision Agent',
    description: 'Parse the diagram into entities, relationships, labels, and spatial layout.',
    icon: 'ScanEye',
  },
  {
    id: 'question-generation',
    label: 'Question Generation',
    short: 'Generate',
    agent: 'Question Agent',
    description: 'Generate Bloom\'s-conditioned questions grounded in the extracted structure.',
    icon: 'MessageSquarePlus',
  },
  {
    id: 'answering',
    label: 'Answering Agent',
    short: 'Answer',
    agent: 'Answer Agent',
    description: 'Independently answer each question using only the diagram, to cross-check for leaks.',
    icon: 'Sparkles',
  },
  {
    id: 'verification',
    label: 'Verification Loop',
    short: 'Verify',
    agent: 'Verify Agent',
    description: 'Check Q&A pairs for correctness, ambiguity, and difficulty-label accuracy; can reject and trigger regeneration.',
    icon: 'ShieldCheck',
  },
  {
    id: 'results',
    label: 'Results',
    short: 'Results',
    agent: 'Curation',
    description: 'Review verified Q&A pairs, ranked by quality and Bloom\'s coverage.',
    icon: 'Trophy',
  },
]

export function getStageMeta(id: StageId): StageMeta {
  return PIPELINE_STAGES.find((s) => s.id === id) ?? PIPELINE_STAGES[0]
}

/** Tailwind class strings per status — kept here so the sidebar and main panel stay in sync. */
export const STATUS_STYLES: Record<StageStatus, { dot: string; ring: string; label: string }> = {
  idle: {
    dot: 'bg-foreground/20',
    ring: 'ring-foreground/10',
    label: 'text-muted-foreground',
  },
  running: {
    dot: 'bg-agent shadow-[0_0_8px_var(--agent-glow)]',
    ring: 'ring-agent/40',
    label: 'text-agent',
  },
  done: {
    dot: 'bg-emerald-400',
    ring: 'ring-emerald-400/30',
    label: 'text-emerald-400',
  },
  flagged: {
    dot: 'bg-amber-400',
    ring: 'ring-amber-400/30',
    label: 'text-amber-400',
  },
  rejected: {
    dot: 'bg-red-400',
    ring: 'ring-red-400/30',
    label: 'text-red-400',
  },
}
