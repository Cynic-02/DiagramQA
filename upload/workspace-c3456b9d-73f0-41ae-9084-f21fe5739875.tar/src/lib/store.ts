'use client'

import { create } from 'zustand'
import { devtools } from 'zustand/middleware'
import type {
  AgentLogLine,
  BloomLevel,
  ExtractionResult,
  PipelineRunMeta,
  QAPair,
  StageId,
  StageState,
  StageStatus,
} from './types'
import { PIPELINE_STAGES } from './bloom'

export interface DiagramRef {
  name: string
  mimeType: string
  dataUrl: string
}

interface PipelineStore {
  // ── Connection ──────────────────────────────────────────────────────────
  socketConnected: boolean
  setSocketConnected: (v: boolean) => void

  // ── Run config ──────────────────────────────────────────────────────────
  diagram: DiagramRef | null
  setDiagram: (d: DiagramRef | null) => void

  bloom: BloomLevel
  setBloom: (b: BloomLevel) => void

  questionCount: number
  setQuestionCount: (n: number) => void

  // ── Run state ────────────────────────────────────────────────────────────
  runId: string | null
  running: boolean
  error: string | null
  meta: PipelineRunMeta | null

  stages: Record<StageId, StageState>
  activeStage: StageId
  setActiveStage: (s: StageId) => void

  // ── Right panel (Context / Log drawer) ───────────────────────────────────
  rightPanelOpen: boolean
  setRightPanelOpen: (v: boolean) => void
  toggleRightPanel: () => void

  // ── Streaming text (typewriter) ──────────────────────────────────────────
  // Per-question streaming buffers for the typewriter effect.
  streamingQuestion: Record<string, string> // questionId -> partial text
  streamingAnswer: Record<string, string> // questionId -> partial text
  setStreamingQuestion: (id: string, text: string) => void
  setStreamingAnswer: (id: string, text: string) => void
  clearStreaming: () => void

  // ── Outputs ──────────────────────────────────────────────────────────────
  extraction: ExtractionResult | null
  pairs: QAPair[]
  logs: AgentLogLine[]

  // ── Actions ──────────────────────────────────────────────────────────────
  resetRun: () => void
  startRun: (runId: string) => void
  setStage: (stage: StageId, status: StageStatus, note?: string) => void
  setExtraction: (e: ExtractionResult) => void
  upsertQuestion: (pair: QAPair) => void
  upsertAnswer: (questionId: string, answer: QAPair['answer']) => void
  upsertVerification: (questionId: string, v: QAPair['verification']) => void
  markRegenerate: (questionId: string, reason: string) => void
  completeRun: (meta: PipelineRunMeta) => void
  setError: (msg: string | null) => void
  pushLog: (line: Omit<AgentLogLine, 'ts'>) => void
}

function makeInitialStages(): Record<StageId, StageState> {
  const out = {} as Record<StageId, StageState>
  for (const s of PIPELINE_STAGES) {
    out[s.id] = { id: s.id, status: 'idle', updatedAt: 0 }
  }
  return out
}

export const usePipelineStore = create<PipelineStore>()(
  devtools(
    (set, get) => ({
      socketConnected: false,
      setSocketConnected: (v) => set({ socketConnected: v }),

      diagram: null,
      setDiagram: (d) => set({ diagram: d }),

      bloom: 'apply',
      setBloom: (b) => set({ bloom: b }),

      questionCount: 4,
      setQuestionCount: (n) => set({ questionCount: n }),

      runId: null,
      running: false,
      error: null,
      meta: null,

      stages: makeInitialStages(),
      activeStage: 'upload',
      setActiveStage: (s) =>
        set((state) => ({
          activeStage: s,
          // Auto-open the right panel when navigating to a stage that has data.
          rightPanelOpen:
            s !== 'upload' && (state.stages[s].status !== 'idle' || s === 'results'),
        })),

      rightPanelOpen: false,
      setRightPanelOpen: (v) => set({ rightPanelOpen: v }),
      toggleRightPanel: () => set((state) => ({ rightPanelOpen: !state.rightPanelOpen })),

      streamingQuestion: {},
      streamingAnswer: {},
      setStreamingQuestion: (id, text) =>
        set((state) => ({
          streamingQuestion: { ...state.streamingQuestion, [id]: text },
        })),
      setStreamingAnswer: (id, text) =>
        set((state) => ({
          streamingAnswer: { ...state.streamingAnswer, [id]: text },
        })),
      clearStreaming: () => set({ streamingQuestion: {}, streamingAnswer: {} }),

      extraction: null,
      pairs: [],
      logs: [],

      resetRun: () =>
        set({
          runId: null,
          running: false,
          error: null,
          meta: null,
          stages: makeInitialStages(),
          extraction: null,
          pairs: [],
          logs: [],
          activeStage: 'upload',
          streamingQuestion: {},
          streamingAnswer: {},
          rightPanelOpen: false,
        }),

      startRun: (runId) =>
        set({
          runId,
          running: true,
          error: null,
          meta: null,
          stages: makeInitialStages(),
          extraction: null,
          pairs: [],
          logs: [],
          activeStage: 'extraction',
          rightPanelOpen: true,
          streamingQuestion: {},
          streamingAnswer: {},
        }),

      setStage: (stage, status, note) =>
        set((state) => {
          // Auto-advance the active stage when a new one starts.
          const activeStage = status === 'running' ? stage : state.activeStage
          // Auto-open right panel when a stage starts running.
          const rightPanelOpen = status === 'running' ? true : state.rightPanelOpen
          return {
            stages: {
              ...state.stages,
              [stage]: { id: stage, status, updatedAt: Date.now(), note },
            },
            activeStage,
            rightPanelOpen,
          }
        }),

      setExtraction: (e) => set({ extraction: e }),

      upsertQuestion: (pair) =>
        set((state) => {
          const idx = state.pairs.findIndex((p) => p.id === pair.id)
          if (idx === -1) return { pairs: [...state.pairs, pair] }
          const next = [...state.pairs]
          next[idx] = { ...next[idx], ...pair, question: pair.question }
          return { pairs: next }
        }),

      upsertAnswer: (questionId, answer) =>
        set((state) => ({
          pairs: state.pairs.map((p) =>
            p.id === questionId ? { ...p, answer } : p,
          ),
        })),

      upsertVerification: (questionId, v) =>
        set((state) => ({
          pairs: state.pairs.map((p) =>
            p.id === questionId ? { ...p, verification: v } : p,
          ),
        })),

      markRegenerate: (questionId, reason) =>
        set((state) => ({
          pairs: state.pairs.map((p) =>
            p.id === questionId
              ? {
                  ...p,
                  attempts: p.attempts + 1,
                  answer: null,
                  verification: { ...v_default(p), notes: reason },
                }
              : p,
          ),
        })),

      completeRun: (meta) =>
        set({ running: false, meta, activeStage: 'results' }),

      setError: (msg) => set({ error: msg, running: false }),

      pushLog: (line) =>
        set((state) => ({
          logs: [...state.logs, { ...line, ts: Date.now() }].slice(-500),
        })),
    }),
    { name: 'ar2-ddcqg' },
  ),
)

// helper for the regenerate action — kept here to avoid circular imports
function v_default(p: QAPair): import('./types').VerificationResult {
  return {
    questionId: p.id,
    verdict: 'regenerate',
    correct: false,
    ambiguity: 0,
    difficultyMatch: 0,
    notes: '',
    leaksAnswer: false,
  }
}
