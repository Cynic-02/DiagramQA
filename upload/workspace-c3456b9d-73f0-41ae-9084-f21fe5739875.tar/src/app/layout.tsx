import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/theme-provider";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "AR2-DDCQG — Diagram-Driven Question Generation",
  description:
    "Agentic, Retrieval-Augmented, Diagram-Driven Course Question Generation. A multi-agent pipeline that turns any diagram into verified Bloom's-graded Q&A.",
  keywords: [
    "AR2-DDCQG",
    "multi-agent",
    "diagram question generation",
    "Bloom's taxonomy",
    "vision LLM",
    "verification loop",
  ],
  authors: [{ name: "AR2-DDCQG Team" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "AR2-DDCQG",
    description:
      "Multi-agent diagram-to-question pipeline with Bloom's difficulty conditioning.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning className="dark">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground min-h-screen`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem={false}
          disableTransitionOnChange
        >
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
