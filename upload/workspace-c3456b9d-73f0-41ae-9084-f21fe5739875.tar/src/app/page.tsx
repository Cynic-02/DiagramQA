'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import HeroSection from '@/components/hero/hero-section'
import AppShell from '@/components/pipeline/app-shell'

export default function Home() {
  // App starts in hero mode, transitions to the workspace on user action
  // or when they scroll past the hero.
  const [entered, setEntered] = useState(false)

  // Lock body scroll while in the hero so the sticky scroll choreography works.
  useEffect(() => {
    if (entered) {
      document.body.style.overflow = 'auto'
    } else {
      document.body.style.overflow = 'auto'
    }
    return () => {
      document.body.style.overflow = 'auto'
    }
  }, [entered])

  // Esc returns to the hero.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && entered) setEntered(false)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [entered])

  return (
    <AnimatePresence mode="wait">
      {!entered ? (
        <motion.div
          key="hero"
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
        >
          <HeroSection onEnter={() => setEntered(true)} />
        </motion.div>
      ) : (
        <motion.div
          key="app"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          className="h-screen"
        >
          <AppShell onExit={() => setEntered(false)} />
        </motion.div>
      )}
    </AnimatePresence>
  )
}
